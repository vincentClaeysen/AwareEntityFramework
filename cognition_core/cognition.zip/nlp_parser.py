"""
nlp_parser.py — Parseur d'intentions basé sur spaCy
Version 1.0.0

Remplace _text_to_intent de CognitionCore.

Pipeline :
  1. Analyse morpho-syntaxique (spaCy fr_core_news_sm)
  2. Extraction d'entités (NER spaCy + entités personnalisées du graphe)
  3. Classification d'intention via patterns Matcher (chargés depuis JSON)
  4. Extraction de slots selon les entités trouvées
  5. Résolution de contexte (pronoms, ellipses)

Usage :
    parser = IntentParser(graph, context, patterns_dir="./patterns")
    intent = parser.parse("c'est quelle saison ?", conversation_id="conv_abc")
"""

import json
import time
import uuid
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any

import spacy
from spacy.matcher import Matcher, PhraseMatcher
from spacy.tokens import Doc, Span

# Types locaux — on les importe depuis cognition_core en production
# Ici déclarés pour autonomie du module
from dataclasses import dataclass, field
from enum import Enum


logger = logging.getLogger("NLPParser")


# ============================================================
# RÉSULTAT D'ANALYSE
# ============================================================

@dataclass
class ParseResult:
    """Résultat intermédiaire avant construction d'un StructuredIntent."""
    intent: str
    sub_intent: str
    confidence: float
    entities: Dict[str, Any]          # slot_name → valeur extraite
    raw_entities: List[Dict]           # entités NER brutes
    sentence_type: str                 # declaratif / interrogatif / imperatif
    negated: bool
    language: str = "fr"
    matched_pattern_id: Optional[str] = None


# ============================================================
# MORPHOLOGIE FRANÇAISE (détection)
# ============================================================

class FrenchMorphAnalyzer:
    """
    Analyses morphologiques sur un Doc spaCy :
    détection du type de phrase, négation, polarité.
    """

    QUESTION_WORDS = {"qui", "que", "quoi", "quand", "où", "comment",
                      "pourquoi", "combien", "quel", "quelle", "quels", "quelles",
                      "lequel", "laquelle", "lesquels", "lesquelles"}

    NEG_TOKENS = {"ne", "n'", "pas", "jamais", "plus", "rien", "personne",
                  "guère", "nullement", "aucun", "aucune"}

    IMPERATIVE_VERBS = {"dis", "dis-moi", "donne", "donne-moi", "montre",
                         "explique", "aide", "arrête", "viens", "va"}

    @classmethod
    def detect_sentence_type(cls, doc: Doc) -> str:
        """Détecte le type de phrase : interrogatif, impératif, déclaratif."""
        text = doc.text.strip()

        # Interrogation explicite
        if text.endswith("?"):
            return "interrogatif"

        # Mots interrogatifs en début ou après sujet
        for token in doc[:4]:
            if token.lower_ in cls.QUESTION_WORDS:
                return "interrogatif"

        # Inversion sujet-verbe (est-il, est-ce que)
        for i, token in enumerate(doc[:-1]):
            if token.lower_ in {"est-il", "est-elle", "est-ce"}:
                return "interrogatif"
            if token.dep_ == "ROOT" and token.pos_ == "VERB":
                next_tok = doc[i + 1]
                if next_tok.lower_ in {"-il", "-elle", "-on", "-tu", "-vous"}:
                    return "interrogatif"

        # Impératif
        for token in doc[:3]:
            if token.lower_ in cls.IMPERATIVE_VERBS:
                return "imperatif"
            if token.pos_ == "VERB" and token.morph.get("Mood") == ["Imp"]:
                return "imperatif"

        return "declaratif"

    @classmethod
    def detect_negation(cls, doc: Doc) -> bool:
        """Détecte si la phrase principale est à la forme négative."""
        neg_count = 0
        for token in doc:
            if token.lower_ in cls.NEG_TOKENS:
                neg_count += 1
        # Négation française = généralement 2 marqueurs (ne...pas)
        # ou 1 pour les formes contractées (n'importe)
        return neg_count >= 1

    @classmethod
    def extract_register_hints(cls, doc: Doc) -> List[str]:
        """Indices du registre : présence de vouvoiement, argot, etc."""
        hints = []
        text_lower = doc.text.lower()

        if any(t.lower_ in {"vous", "votre", "vos"} for t in doc):
            hints.append("vouvoiement")
        if any(t.lower_ in {"mec", "gars", "truc", "machin", "putain", "wesh"}
               for t in doc):
            hints.append("familier")
        if any(t.lower_ in {"certes", "néanmoins", "toutefois", "nonobstant"}
               for t in doc):
            hints.append("soutenu")

        return hints


# ============================================================
# CHARGEUR DE PATTERNS
# ============================================================

class PatternLoader:
    """
    Charge les patterns depuis des fichiers JSON par domaine
    et les enregistre dans un Matcher spaCy.
    """

    def __init__(self, patterns_dir: Path, nlp):
        self.patterns_dir = Path(patterns_dir)
        self.nlp = nlp
        self.matcher = Matcher(nlp.vocab)
        self.phrase_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")

        # Registre : pattern_key → (intent, sub_intent, confidence, entity_slots)
        self.pattern_registry: Dict[str, Dict] = {}

        self._loaded_domains: List[str] = []

    def load_domain(self, domain: str) -> bool:
        """Charge un fichier de patterns JSON pour un domaine."""
        filepath = self.patterns_dir / f"{domain}.json"
        if not filepath.exists():
            logger.warning(f"Fichier de patterns introuvable : {filepath}")
            return False

        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        domain_name = data.get("domain", domain)
        intent_patterns = data.get("intent_patterns", [])

        for entry in intent_patterns:
            intent = entry["intent"]
            sub_intent = entry["sub_intent"]
            confidence = entry.get("confidence", 0.8)
            entity_slots = entry.get("entity_slots", {})

            for i, pattern in enumerate(entry.get("patterns", [])):
                key = f"{domain_name}__{intent}__{sub_intent}__{i}"

                # Convertir les patterns JSON en format spaCy
                spacy_pattern = self._convert_pattern(pattern)
                if spacy_pattern:
                    try:
                        self.matcher.add(key, [spacy_pattern])
                        self.pattern_registry[key] = {
                            "intent": intent,
                            "sub_intent": sub_intent,
                            "confidence": confidence,
                            "entity_slots": entity_slots,
                            "domain": domain_name
                        }
                    except Exception as e:
                        logger.debug(f"Pattern ignoré {key}: {e}")

        self._loaded_domains.append(domain_name)
        logger.info(f"Domaine '{domain_name}' chargé : {len(intent_patterns)} intentions")
        return True

    def _convert_pattern(self, pattern: List[Dict]) -> Optional[List[Dict]]:
        """
        Convertit un pattern JSON en format spaCy Matcher.
        Filtre les attributs non supportés par le modèle courant.
        """
        spacy_pattern = []
        supported_attrs = {
            "LOWER", "TEXT", "LEMMA", "POS", "TAG", "DEP",
            "ENT_TYPE", "LIKE_NUM", "IS_ALPHA", "IS_DIGIT",
            "OP", "IN", "NOT_IN", "REGEX"
        }

        for token_spec in pattern:
            converted = {}
            for k, v in token_spec.items():
                if k in supported_attrs:
                    converted[k] = v
                elif k == "LOWER" and isinstance(v, dict):
                    converted["LOWER"] = v
            if converted:
                spacy_pattern.append(converted)

        return spacy_pattern if spacy_pattern else None

    def match(self, doc: Doc) -> List[Tuple[str, int, int]]:
        """Retourne les matches (key, start, end) sur un Doc."""
        matches = self.matcher(doc)
        return [(self.nlp.vocab.strings[match_id], start, end)
                for match_id, start, end in matches]

    def get_registry_entry(self, key: str) -> Optional[Dict]:
        return self.pattern_registry.get(key)


# ============================================================
# EXTRACTEUR DE SLOTS
# ============================================================

class SlotExtractor:
    """
    Extrait les slots (entités typées) depuis un Doc spaCy
    selon les spécifications entity_slots des patterns.
    """

    @classmethod
    def extract(cls, doc: Doc, entity_slots: Dict, span: Span = None) -> Dict[str, Any]:
        """
        Extrait les slots selon la spécification entity_slots.

        entity_slots exemple:
            {
                "personne": {"type": "ent", "ent_type": "PER"},
                "date": {"type": "ent", "ent_type": "DATE"},
                "intensite": {"type": "keyword", "map": {...}}
            }
        """
        result = {}

        for slot_name, spec in entity_slots.items():
            slot_type = spec.get("type")

            if slot_type == "ent":
                value = cls._extract_ent(doc, spec.get("ent_type", ""))
                if value is not None:
                    result[slot_name] = value

            elif slot_type == "keyword":
                value = cls._extract_keyword(doc, spec.get("map", {}))
                if value is not None:
                    result[slot_name] = value

            elif slot_type == "token_after":
                value = cls._extract_token_after(doc, spec.get("pos", "PROPN"), span)
                if value is not None:
                    result[slot_name] = value

            elif slot_type == "sentiment":
                value = cls._extract_sentiment(
                    doc,
                    spec.get("positive", []),
                    spec.get("negative", [])
                )
                if value is not None:
                    result[slot_name] = value

            elif slot_type == "composite":
                value = cls._extract_composite(doc, spec.get("fields", []))
                if value is not None:
                    result[slot_name] = value

        return result

    @classmethod
    def _extract_ent(cls, doc: Doc, ent_type: str) -> Optional[str]:
        """Extrait la première entité NER du type donné."""
        # Mapping des types spaCy FR → types standard
        type_map = {
            "PER": ["PER", "PERSON"],
            "PERSON": ["PER", "PERSON"],
            "LOC": ["LOC", "GPE", "LOCATION"],
            "DATE": ["DATE"],
            "TIME": ["TIME"],
            "ORG": ["ORG"],
        }
        accepted = type_map.get(ent_type, [ent_type])

        for ent in doc.ents:
            if ent.label_ in accepted:
                return ent.text
        return None

    @classmethod
    def _extract_keyword(cls, doc: Doc, keyword_map: Dict) -> Optional[Any]:
        """Extrait et mappe un mot-clé présent dans le texte."""
        text_lower = doc.text.lower()
        # On cherche d'abord les expressions multi-mots (plus longues d'abord)
        sorted_keys = sorted(keyword_map.keys(), key=len, reverse=True)
        for key in sorted_keys:
            if key in text_lower:
                return keyword_map[key]
        return None

    @classmethod
    def _extract_token_after(cls, doc: Doc, pos: str,
                              span: Optional[Span]) -> Optional[str]:
        """Extrait le token de la POS donnée qui suit le span matché."""
        if span is None:
            return None
        end_idx = span.end
        for token in doc[end_idx:end_idx + 5]:
            if token.pos_ == pos and not token.is_stop:
                return token.text
        return None

    @classmethod
    def _extract_sentiment(cls, doc: Doc, positive: List[str],
                            negative: List[str]) -> Optional[Dict]:
        """Détecte la polarité (positif/négatif/neutre)."""
        text_lower = doc.text.lower()
        pos_score = sum(1 for p in positive if p in text_lower)
        neg_score = sum(1 for n in negative if n in text_lower)

        if pos_score > neg_score:
            return {"valence": "positif", "score": pos_score}
        elif neg_score > pos_score:
            return {"valence": "negatif", "score": -neg_score}
        return {"valence": "neutre", "score": 0}

    @classmethod
    def _extract_composite(cls, doc: Doc, fields: List[str]) -> Optional[Dict]:
        """Extrait un slot composite (ex: quantite + unite de durée)."""
        result = {}
        for token in doc:
            if "quantite" in fields and token.like_num:
                result["quantite"] = token.text
            if "unite" in fields and token.lower_ in {
                "heure", "heures", "minute", "minutes",
                "seconde", "secondes", "jour", "jours",
                "semaine", "semaines", "mois", "an", "ans", "année", "années"
            }:
                result["unite"] = token.lower_
        return result if result else None


# ============================================================
# RÉSOLVEUR DE CONTEXTE
# ============================================================

class ContextResolver:
    """
    Résout les références anaphoriques (pronoms → entités)
    et les ellipses à partir du ContextFrame courant.
    """

    PERSONAL_PRONOUNS = {
        "il": "masc_sing", "elle": "fem_sing",
        "ils": "masc_plur", "elles": "fem_plur",
        "lui": "masc_sing", "leur": "plur"
    }

    @classmethod
    def resolve(cls, parse_result: ParseResult,
                context_frame, doc: Doc) -> ParseResult:
        """
        Enrichit le parse_result avec les résolutions contextuelles.
        context_frame : ContextFrame de cognition_core
        """
        if context_frame is None:
            return parse_result

        # Résolution de pronoms pour le slot "personne"
        if "personne" not in parse_result.entities:
            for token in doc:
                if token.lower_ in cls.PERSONAL_PRONOUNS:
                    # Chercher le dernier sujet PERSON mentionné
                    if hasattr(context_frame, "subjects") and context_frame.subjects:
                        parse_result.entities["personne"] = context_frame.subjects[-1]
                        parse_result.entities["personne_resolved"] = True
                    break

        # Résolution d'ellipse : question sans sujet explicite
        # "et toi ?" → reprend le sub_intent de la question précédente
        if (parse_result.intent == "question"
                and parse_result.sub_intent == "etat_interlocuteur"
                and len(doc) <= 3):
            if hasattr(context_frame, "history") and context_frame.history:
                parse_result.entities["ellipse_context"] = "retour_question"

        return parse_result


# ============================================================
# INTENT PARSER PRINCIPAL
# ============================================================

class IntentParser:
    """
    Parseur d'intentions principal.

    Intègre :
    - spaCy pour l'analyse morpho-syntaxique et NER
    - PatternLoader pour le matching par domaine
    - SlotExtractor pour l'extraction d'entités typées
    - FrenchMorphAnalyzer pour le type de phrase et la négation
    - ContextResolver pour la résolution anaphorique
    """

    MODEL_NAME = "fr_core_news_sm"

    def __init__(self, patterns_dir: Path = Path("./patterns"),
                 domains: Optional[List[str]] = None,
                 graph=None):
        """
        patterns_dir : répertoire contenant les fichiers JSON de patterns
        domains      : liste des domaines à charger (None = tous)
        graph        : KnowledgeGraph pour enrichir la NER
        """
        self.graph = graph

        logger.info(f"Chargement du modèle spaCy '{self.MODEL_NAME}'...")
        try:
            self.nlp = spacy.load(self.MODEL_NAME)
        except OSError:
            raise RuntimeError(
                f"Modèle spaCy '{self.MODEL_NAME}' introuvable.\n"
                f"Installez-le avec : python -m spacy download {self.MODEL_NAME}"
            )

        self.morph = FrenchMorphAnalyzer()
        self.loader = PatternLoader(patterns_dir, self.nlp)
        self.slot_extractor = SlotExtractor()
        self.context_resolver = ContextResolver()

        # Charger les domaines
        if domains is None:
            patterns_path = Path(patterns_dir)
            if patterns_path.exists():
                domains = [p.stem for p in patterns_path.glob("*.json")]
            else:
                domains = []

        for domain in (domains or []):
            self.loader.load_domain(domain)

        # Fallback : intention générique si aucun pattern ne matche
        self._fallback_intent = {
            "interrogatif": ("question", "general", 0.4),
            "imperatif":    ("action",   "general", 0.4),
            "declaratif":   ("information", "statement", 0.3)
        }

        logger.info(f"IntentParser prêt — domaines : {self.loader._loaded_domains}")

    # ----------------------------------------------------------
    # POINT D'ENTRÉE
    # ----------------------------------------------------------

    def parse(self, text: str,
              context_frame=None,
              conversation_id: str = "",
              speaker: str = "unknown") -> ParseResult:
        """
        Analyse un texte et retourne un ParseResult.

        text           : texte brut de l'utilisateur
        context_frame  : ContextFrame courant (pour résolution contextuelle)
        conversation_id: identifiant de la conversation
        speaker        : identifiant du locuteur
        """
        text = text.strip()
        if not text:
            return self._make_empty_result()

        doc = self.nlp(text)

        # 1. Analyse morphologique
        sentence_type = self.morph.detect_sentence_type(doc)
        negated = self.morph.detect_negation(doc)
        register_hints = self.morph.extract_register_hints(doc)

        # 2. Matching de patterns
        matches = self.loader.match(doc)

        best_result = None
        best_confidence = 0.0

        for key, start, end in matches:
            entry = self.loader.get_registry_entry(key)
            if entry is None:
                continue

            span = doc[start:end]
            confidence = entry["confidence"]

            # Bonus de confiance selon le type de phrase
            if (sentence_type == "interrogatif"
                    and entry["intent"] in {"question", "clarification"}):
                confidence = min(1.0, confidence + 0.05)
            elif (sentence_type == "declaratif"
                  and entry["intent"] == "information"):
                confidence = min(1.0, confidence + 0.03)

            # Pénalité pour les patterns très courts (bruit)
            if end - start <= 1:
                confidence -= 0.1

            if confidence > best_confidence:
                best_confidence = confidence
                entities = self.slot_extractor.extract(
                    doc, entry["entity_slots"], span=span
                )
                best_result = ParseResult(
                    intent=entry["intent"],
                    sub_intent=entry["sub_intent"],
                    confidence=confidence,
                    entities=entities,
                    raw_entities=[{
                        "text": ent.text,
                        "label": ent.label_,
                        "start": ent.start_char,
                        "end": ent.end_char
                    } for ent in doc.ents],
                    sentence_type=sentence_type,
                    negated=negated,
                    matched_pattern_id=key
                )

        # 3. Fallback si aucun pattern
        if best_result is None or best_confidence < 0.3:
            fb_intent, fb_sub, fb_conf = self._fallback_intent.get(
                sentence_type, ("information", "statement", 0.2)
            )
            # Extraire quand même les entités NER brutes
            raw_ents = [{"text": e.text, "label": e.label_,
                          "start": e.start_char, "end": e.end_char}
                         for e in doc.ents]

            # Pour les questions génériques, tenter d'extraire le sujet
            entities = {}
            if sentence_type == "interrogatif":
                per = self.slot_extractor._extract_ent(doc, "PER")
                if per:
                    entities["personne"] = per
                date = self.slot_extractor._extract_ent(doc, "DATE")
                if date:
                    entities["date"] = date

            best_result = ParseResult(
                intent=fb_intent,
                sub_intent=fb_sub,
                confidence=fb_conf,
                entities=entities,
                raw_entities=raw_ents,
                sentence_type=sentence_type,
                negated=negated
            )

        # 4. Résolution contextuelle
        if context_frame is not None:
            best_result = self.context_resolver.resolve(
                best_result, context_frame, doc
            )

        # 5. Enrichissement depuis le graphe (entités connues non détectées par NER)
        if self.graph is not None:
            best_result = self._enrich_from_graph(best_result, doc)

        logger.debug(
            f"Parse '{text[:40]}' → {best_result.intent}/{best_result.sub_intent} "
            f"(conf={best_result.confidence:.2f})"
        )
        return best_result

    # ----------------------------------------------------------
    # ENRICHISSEMENT DEPUIS LE GRAPHE
    # ----------------------------------------------------------

    def _enrich_from_graph(self, result: ParseResult, doc: Doc) -> ParseResult:
        """
        Pour chaque token non détecté par NER, vérifie si le graphe le connaît
        et injecte l'information dans les entités.
        """
        if "personne" not in result.entities:
            for token in doc:
                if token.is_alpha and not token.is_stop and len(token.text) > 2:
                    concept = self.graph.get(token.text)
                    if concept and concept.nature.value == "personne":
                        result.entities["personne"] = token.text
                        break

        return result

    # ----------------------------------------------------------
    # UTILITAIRES
    # ----------------------------------------------------------

    def _make_empty_result(self) -> ParseResult:
        return ParseResult(
            intent="social",
            sub_intent="salutation",
            confidence=0.1,
            entities={},
            raw_entities=[],
            sentence_type="declaratif",
            negated=False
        )

    def load_domain(self, domain: str) -> bool:
        """Charge un domaine de patterns à la volée."""
        return self.loader.load_domain(domain)

    @property
    def loaded_domains(self) -> List[str]:
        return list(self.loader._loaded_domains)
