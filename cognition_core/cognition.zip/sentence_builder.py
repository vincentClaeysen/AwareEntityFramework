"""
sentence_builder.py — Générateur de texte à partir d'intents
Version 1.0.0

Remplace SentenceBuilder de cognition_core.

Architecture :
  - Templates chargés depuis des fichiers JSON par domaine
  - Sélection du meilleur template selon :
      • register (familier / neutre / soutenu)
      • style_prefere du Gem
      • humeur_actuelle du Gem
      • conditions sur les slots
  - Remplissage des slots avec transformations morphologiques
  - Post-traitement : élisions, majuscule, ponctuation

Usage :
    builder = TemplateBuilder(gem, morpho, templates_dir="./templates")
    texte = builder.build(intent)
"""

import json
import random
import logging
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

logger = logging.getLogger("TemplateBuilder")


# ============================================================
# SÉLECTEUR DE TEMPLATE
# ============================================================

class TemplateSelector:
    """
    Sélectionne le meilleur variant parmi une liste
    selon le profil Gem et le contexte.
    """

    def select(self, variants: List[Dict], gem,
               register: Optional[str] = None,
               slots: Dict[str, Any] = None) -> Optional[Dict]:
        """
        Sélectionne un variant en tenant compte de :
        - L'humeur du Gem (priorité aux variants humeur-spécifiques)
        - Le style préféré du Gem
        - Le registre courant (fourni par le contexte ou inféré)
        - Les conditions sur les slots
        - Le weight du variant
        """
        if not variants:
            return None

        slots = slots or {}
        humeur = gem.humeur_actuelle
        style = gem.style_prefere

        # Registre cible : celui du contexte > celui du style Gem > neutre
        target_register = register or self._infer_register(gem)

        scored = []

        for variant in variants:
            # 1. Vérification des conditions sur les slots
            if not self._check_conditions(variant.get("condition", {}), slots):
                continue

            score = variant.get("weight", 1.0)

            # 2. Bonus humeur
            v_humeur = variant.get("humeur")
            if v_humeur is None:
                score += 0.0  # neutre, toujours éligible
            elif isinstance(v_humeur, list):
                if humeur in v_humeur:
                    score += 0.4
                else:
                    score -= 0.3  # pénalité si humeur non correspondante
            elif isinstance(v_humeur, str):
                if humeur == v_humeur:
                    score += 0.4
                else:
                    score -= 0.3

            # 3. Bonus register
            v_register = variant.get("register", "neutre")
            if v_register == target_register:
                score += 0.25
            elif v_register == "neutre":
                score += 0.05  # neutre est toujours acceptable
            else:
                score -= 0.15

            # 4. Bonus style
            v_styles = variant.get("style", [])
            if style in v_styles:
                score += 0.15

            # 5. Ajout d'un léger bruit pour la variété
            score += random.uniform(-0.05, 0.05)

            scored.append((score, variant))

        if not scored:
            # Fallback : prendre le premier variant sans condition
            for v in variants:
                if not v.get("condition"):
                    return v
            return variants[0]

        # Tri par score décroissant, sélection du meilleur
        scored.sort(key=lambda x: x[0], reverse=True)

        # Sélection pondérée parmi le top-3 (pour un peu de variété)
        top = scored[:3]
        total = sum(s for s, _ in top)
        if total <= 0:
            return scored[0][1]

        r = random.uniform(0, total)
        cumul = 0
        for score, variant in top:
            cumul += score
            if r <= cumul:
                return variant

        return scored[0][1]

    def _infer_register(self, gem) -> str:
        """Infère le registre cible depuis les paramètres du Gem."""
        if gem.grace >= 0.7:
            return "soutenu"
        if gem.reactivite >= 0.8:
            return "familier"
        return "neutre"

    def _check_conditions(self, condition: Dict, slots: Dict) -> bool:
        """
        Vérifie que toutes les conditions du variant sont satisfaites.

        Conditions supportées :
            {"slot_name": valeur}                 → égalité exacte
            {"slot_name": {"not_null": true}}     → slot présent et non vide
            {"slot_name": {"gte": valeur}}        → numérique >=
            {"slot_name": {"lte": valeur}}        → numérique <=
        """
        for key, cond in condition.items():
            slot_val = slots.get(key)

            if isinstance(cond, dict):
                if "not_null" in cond:
                    if cond["not_null"] and (slot_val is None or slot_val == ""):
                        return False
                    if not cond["not_null"] and slot_val is not None:
                        return False
                if "gte" in cond:
                    try:
                        if float(slot_val or 0) < float(cond["gte"]):
                            return False
                    except (TypeError, ValueError):
                        return False
                if "lte" in cond:
                    try:
                        if float(slot_val or 0) > float(cond["lte"]):
                            return False
                    except (TypeError, ValueError):
                        return False
            else:
                # Égalité exacte
                if slot_val != cond:
                    return False

        return True


# ============================================================
# TRANSFORMATEUR DE SLOTS
# ============================================================

class SlotTransformer:
    """
    Applique les transformations définies dans les templates
    pour produire des slots dérivés (accord, élision, etc.).
    """

    def __init__(self, morpho, gem):
        self.morpho = morpho
        self.gem = gem

    def apply_transforms(self, slots: Dict[str, Any],
                          transforms: Dict[str, Dict]) -> Dict[str, Any]:
        """
        Calcule les slots dérivés selon les spécifications de transformation.
        Les slots dérivés sont ajoutés au dict de slots.
        """
        derived = {}

        for slot_name, spec in transforms.items():
            transform_type = spec.get("type")
            source = spec.get("source")
            source_val = slots.get(source) if source else None

            try:
                result = self._apply_one(transform_type, spec, source_val, slots)
                if result is not None:
                    derived[slot_name] = result
            except Exception as e:
                logger.debug(f"Transformation '{slot_name}' échouée : {e}")

        return {**slots, **derived}

    def _apply_one(self, transform_type: str, spec: Dict,
                   source_val: Any, slots: Dict) -> Optional[Any]:

        if transform_type == "pluriel_conditionnel":
            seuil = spec.get("seuil", 2)
            try:
                val = float(source_val or 0)
            except (TypeError, ValueError):
                val = 0
            return spec.get("pluriel", "s") if val >= seuil else spec.get("singulier", "")

        elif transform_type == "minutes_verbales":
            cases = spec.get("cases", {})
            try:
                minutes = int(source_val or 0)
            except (TypeError, ValueError):
                minutes = 0
            str_key = str(minutes)
            if str_key in cases:
                val = cases[str_key]
                if val == "":
                    return ""
                return val
            default = spec.get("default", str(minutes))
            return default.replace("{minutes}", str(minutes))

        elif transform_type == "zero_pad":
            width = spec.get("width", 2)
            try:
                return str(int(source_val or 0)).zfill(width)
            except (TypeError, ValueError):
                return "00"

        elif transform_type == "article_contraction":
            articles = spec.get("articles", {})
            if source_val and source_val.lower() in articles:
                return articles[source_val.lower()]
            return "en "

        elif transform_type == "adjectif_humeur":
            humeur = self.gem.humeur_actuelle
            humeur_map = spec.get("humeur_map", {})
            if humeur in humeur_map and source_val:
                return humeur_map[humeur].get(source_val.lower(), "")
            return ""

        elif transform_type == "accord_genre":
            gem_genre = getattr(self.gem, "genre", "masc")
            return spec.get("feminin", "e") if gem_genre == "fem" else spec.get("masculin", "")

        elif transform_type == "article_elude":
            genre = spec.get("genre", "masc")
            nombre = spec.get("nombre", "sing")
            type_art = spec.get("article_type", "def")
            if source_val:
                return self.morpho.article(source_val, type_art, genre, nombre)
            return ""

        elif transform_type == "pluriel":
            genre = spec.get("genre", "masc")
            if source_val:
                return self.morpho.pluriel(str(source_val), genre)
            return ""

        elif transform_type == "feminin":
            if source_val:
                return self.morpho.feminin(str(source_val))
            return source_val

        elif transform_type == "accord_adj":
            genre = slots.get(spec.get("genre_source", "genre"), "masc")
            nombre = slots.get(spec.get("nombre_source", "nombre"), "sing")
            if source_val:
                return self.morpho.accord_adj(str(source_val), genre, nombre)
            return source_val

        return None


# ============================================================
# REMPLISSEUR DE TEMPLATE
# ============================================================

class TemplateFiller:
    """
    Remplace les slots {slot_name} dans un template string,
    avec gestion des slots optionnels et des valeurs vides.
    """

    SLOT_RE = re.compile(r"\{(\w+)\}")

    @classmethod
    def fill(cls, template: str, slots: Dict[str, Any]) -> str:
        """
        Remplace tous les {slot_name} par leur valeur.
        Les slots absents sont remplacés par "".
        """
        def replacer(m):
            key = m.group(1)
            val = slots.get(key)
            if val is None:
                return ""
            return str(val)

        result = cls.SLOT_RE.sub(replacer, template)

        # Nettoyer les espaces multiples laissés par des slots vides
        result = re.sub(r"  +", " ", result).strip()
        result = re.sub(r" \.", ".", result)
        result = re.sub(r" ,", ",", result)
        result = re.sub(r" !", "!", result)
        result = re.sub(r" \?", "?", result)

        return result


# ============================================================
# BUILDER PRINCIPAL
# ============================================================

class TemplateBuilder:
    """
    Constructeur de texte principal.

    Charge les templates depuis des fichiers JSON par domaine,
    sélectionne le meilleur variant, remplit les slots,
    applique les transformations morphologiques et le post-traitement.
    """

    def __init__(self, gem, morpho, templates_dir: Path = Path("./templates")):
        self.gem = gem
        self.morpho = morpho
        self.templates_dir = Path(templates_dir)

        self.selector = TemplateSelector()
        self.transformer = SlotTransformer(morpho, gem)
        self.filler = TemplateFiller()

        # Registre global : "intent/sub_intent" → {slots, variants, transforms}
        self._registry: Dict[str, Dict] = {}
        self._fallback_templates: Dict[str, str] = {
            "reponse/defaut": "D'accord.",
            "question/general": "Que veux-tu savoir ?",
            "clarification/general": "Je n'ai pas compris. Peux-tu reformuler ?",
            "social/salutation": "Bonjour.",
            "social/conge": "Au revoir.",
            "social/remerciement": "Avec plaisir.",
            "acknowledge/information": "D'accord.",
            "acknowledge/default": "D'accord.",
        }

        self._loaded_domains: List[str] = []

    def load_domain(self, domain: str) -> bool:
        """Charge les templates d'un domaine depuis un fichier JSON."""
        filepath = self.templates_dir / f"{domain}.json"
        if not filepath.exists():
            logger.warning(f"Fichier de templates introuvable : {filepath}")
            return False

        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        templates = data.get("templates", {})
        transforms_global = data.get("slot_transforms", {})

        for key, tpl_data in templates.items():
            self._registry[key] = {
                "slots": tpl_data.get("slots", []),
                "variants": tpl_data.get("variants", []),
                "transforms": {**transforms_global,
                               **tpl_data.get("transforms", {})}
            }

        self._loaded_domains.append(domain)
        logger.info(f"Templates '{domain}' chargés : {len(templates)} clés")
        return True

    def load_all_domains(self):
        """Charge tous les fichiers JSON du répertoire templates."""
        if self.templates_dir.exists():
            for fp in self.templates_dir.glob("*.json"):
                self.load_domain(fp.stem)

    # ----------------------------------------------------------
    # POINT D'ENTRÉE
    # ----------------------------------------------------------

    def build(self, intent, context_frame=None) -> Optional[str]:
        """
        Construit un texte à partir d'un StructuredIntent.

        intent        : StructuredIntent de cognition_core
        context_frame : ContextFrame pour le registre courant
        """
        # 1. Clé de lookup
        intent_type = intent.semantic.get("type", "")
        sub_intent = intent.semantic.get("sub_intent", "")
        key = f"{intent_type}/{sub_intent}"

        # 2. Extraire les slots depuis les attributs de l'intent
        raw_slots = self._extract_slots_from_intent(intent)

        # 3. Enrichir avec le contexte temporel
        raw_slots = self._enrich_temporal_slots(raw_slots)

        # 4. Registre depuis le contexte
        register = None
        if context_frame and hasattr(context_frame, "register"):
            if context_frame.register:
                register = context_frame.register.value if hasattr(
                    context_frame.register, "value") else str(context_frame.register)

        # 5. Chercher dans le registre
        tpl_data = self._registry.get(key)

        if not tpl_data:
            # Essayer avec juste l'intent_type
            tpl_data = self._registry.get(f"{intent_type}/defaut")

        if not tpl_data:
            return self._fallback(key, raw_slots)

        # 6. Appliquer les transformations
        transforms = tpl_data.get("transforms", {})
        slots = self.transformer.apply_transforms(raw_slots, transforms)

        # 7. Sélectionner le variant
        variant = self.selector.select(
            tpl_data["variants"],
            self.gem,
            register=register,
            slots=slots
        )

        if not variant:
            return self._fallback(key, slots)

        # 8. Remplir le template
        template_str = variant.get("template", "")
        text = self.filler.fill(template_str, slots)

        # 9. Post-traitement morphologique
        text = self._post_process(text, slots)

        logger.debug(f"build '{key}' → variant '{variant.get('id')}' → '{text}'")
        return text if text else self._fallback(key, slots)

    # ----------------------------------------------------------
    # EXTRACTION DES SLOTS
    # ----------------------------------------------------------

    def _extract_slots_from_intent(self, intent) -> Dict[str, Any]:
        """Extrait les valeurs de slots depuis les attributs de l'intent."""
        slots = {}

        for attr_name, attr in intent.attributes.items():
            val = attr.value

            # Traitement spécial selon le type
            if attr.type == "datetime":
                try:
                    dt = datetime.fromisoformat(str(val))
                    slots["heure"] = dt.hour
                    slots["minutes"] = dt.minute
                    slots["jour"] = dt.day
                    slots["mois_num"] = dt.month
                    slots["mois"] = self._mois_str(dt.month)
                    slots["annee"] = dt.year
                    slots["jour_semaine"] = self._jour_semaine_str(dt.weekday())
                except (ValueError, TypeError):
                    slots[attr_name] = val

            elif attr.type == "object" and isinstance(val, dict):
                # Aplatir les dicts simples
                for k, v in val.items():
                    slots[f"{attr_name}_{k}"] = v
                slots[attr_name] = val.get("name", str(val))

            elif attr.type == "string":
                slots[attr_name] = val

                # Spécial : saison
                if attr_name == "saison":
                    slots["saison"] = val.lower()

            else:
                slots[attr_name] = val

        return slots

    def _enrich_temporal_slots(self, slots: Dict) -> Dict:
        """Enrichit les slots avec des données temporelles calculées."""
        if "saison" not in slots:
            slots["saison"] = self._saison_actuelle()

        if "heure" not in slots:
            now = datetime.now()
            slots.setdefault("heure_systeme", now.hour)
            slots.setdefault("minutes_systeme", now.minute)

        return slots

    # ----------------------------------------------------------
    # POST-TRAITEMENT
    # ----------------------------------------------------------

    def _post_process(self, text: str, slots: Dict) -> str:
        """
        Post-traitement final :
        - Élisions
        - Majuscule de début
        - Ponctuation terminale
        """
        # Élisions
        text = self.morpho.elider(text)

        # Majuscule
        text = self.morpho.majuscule(text)

        # Ponctuation terminale
        if text and text[-1] not in ".!?":
            # Ajouter un point sauf si phrase courte type interjection
            if len(text.split()) > 2:
                text += "."

        return text

    # ----------------------------------------------------------
    # FALLBACK
    # ----------------------------------------------------------

    def _fallback(self, key: str, slots: Dict) -> str:
        """Retourne une réponse de fallback pour une clé inconnue."""
        # Chercher la correspondance la plus proche
        for fb_key, fb_text in self._fallback_templates.items():
            if key.startswith(fb_key.split("/")[0]):
                return fb_text

        return "D'accord."

    # ----------------------------------------------------------
    # UTILITAIRES
    # ----------------------------------------------------------

    MOIS_NOMS = ["", "janvier", "février", "mars", "avril", "mai", "juin",
                 "juillet", "août", "septembre", "octobre", "novembre", "décembre"]

    JOURS_NOMS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]

    def _mois_str(self, n: int) -> str:
        return self.MOIS_NOMS[n] if 1 <= n <= 12 else ""

    def _jour_semaine_str(self, n: int) -> str:
        return self.JOURS_NOMS[n % 7]

    def _saison_actuelle(self) -> str:
        now = datetime.now()
        m, j = now.month, now.day
        if (m == 3 and j >= 20) or m in (4, 5) or (m == 6 and j < 21):
            return "printemps"
        if (m == 6 and j >= 21) or m in (7, 8) or (m == 9 and j < 22):
            return "été"
        if (m == 9 and j >= 22) or m in (10, 11) or (m == 12 and j < 21):
            return "automne"
        return "hiver"

    @property
    def loaded_domains(self) -> List[str]:
        return list(self._loaded_domains)
