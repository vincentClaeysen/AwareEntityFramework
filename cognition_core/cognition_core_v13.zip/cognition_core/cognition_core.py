"""
cognition_core.py — Cœur cognitif refactorisé
Version 13.0.0

Changements vs v12 :
- PreferenceState : enum aime/aime_pas/neutre/indifferent/ne_sait_pas
- Concept enrichi : bloc resonances (dimensions partagées avec Gem)
- Gem enrichi     : resonances + seuil_rejet + poids α/β/γ
- _cognize        : routage question/preference + information/preference
- _answer_preference  : lit PreferenceState depuis le graphe
- _update_preference  : écrit/met à jour PreferenceState dans le graphe
- NOTE : calcul de valorisation (PreferenceEngine complet) reporté
         les squelettes sont en place, les valuations seront branchées plus tard
"""

# ============================================================
# IMPORTS (à fusionner avec les imports existants de v10)
# ============================================================
# Les imports ci-dessous s'ajoutent / remplacent dans cognition_core.py

import json
import logging
import time
import uuid
import threading
import queue
import sqlite3
import gzip
import pickle
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Set, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
from collections import defaultdict, OrderedDict
from abc import ABC, abstractmethod
import hashlib

# Nouveaux imports
from nlp_parser import IntentParser, ParseResult
from sentence_builder import GrammarBuilder
from french_morphology import FrenchMorphology
from narrative_store import NarrativeStore

# Tous les modèles v10 restent identiques (Concept, Gem, ContextFrame, etc.)
# On ne redéfinit ici que CognitionCore et ce qui change.

__version__ = "13.0.0"
logger = logging.getLogger("CognitionCore")

# ============================================================
# OPTION GLOBALE — LLM FALLBACK
# ============================================================
# Mettre à False pour désactiver complètement le LLM fallback
# dans tout le pipeline, sans modifier le reste du code.
# Peut aussi être surchargé à l'exécution :
#   import cognition_core; cognition_core.USE_LLM_FALLBACK = False
USE_LLM_FALLBACK: bool = True

# ============================================================
# CONSERVATION INTÉGRALE DE v10
# (IntentType, RelationType, SourceWeight, ConceptNature, MemoryType,
#  StorageLevel, SourceInfo, Relation, Propriete, Concept, Attribute,
#  StructuredIntent, ContextFrame, SystemContext,
#  CompressedStorage, KnowledgeGraph)
#
# → Copier-coller depuis cognition_core v10 sans modification.
# ============================================================

# ============================================================
# ÉTAT DE PRÉFÉRENCE
# ============================================================

class PreferenceState(str, Enum):
    """
    État de préférence de l'entité envers un concept ou une instance.

    AIME         : évaluation positive — résonance et/ou expériences favorables
    AIME_PAS     : évaluation négative — résonance faible et/ou expériences défavorables
    NEUTRE       : évalué, les dimensions positives et négatives s'équilibrent
    INDIFFERENT  : rencontré mais sans résonance significative ni expériences marquantes
    NE_SAIT_PAS  : pas encore suffisamment rencontré pour former une évaluation

    Distinction clé :
      INDIFFERENT ≠ NE_SAIT_PAS
      INDIFFERENT = connu, évalué, pas de résonance particulière
      NE_SAIT_PAS = insuffisamment connu pour évaluer
      NEUTRE      = évalué, tensions équilibrées (peut basculer)
    """
    AIME        = "aime"
    AIME_PAS    = "aime_pas"
    NEUTRE      = "neutre"
    INDIFFERENT = "indifferent"
    NE_SAIT_PAS = "ne_sait_pas"


# Noms des dimensions de résonance partagées Gem ↔ fiches de connaissance
RESONANCE_DIMS = [
    "complexite",
    "imprevisibilite",
    "intensite",
    "sensorialite",
    "partage",
    "rythme",
    "ordre",
    "chaleur",
    "ancrage",
    "familiarite"
]


# ============================================================
# EXTENSIONS GEM (à ajouter dans Gem.from_file)
# ============================================================
# Ces champs sont lus depuis gem.json si présents,
# sinon valeurs par défaut.
#
# "resonances": {
#     "complexite": 0.8, "imprevisibilite": 0.7, "intensite": 0.7,
#     "sensorialite": 0.5, "partage": 0.8, "rythme": 0.5,
#     "ordre": 0.4, "chaleur": 0.7, "ancrage": 0.6, "familiarite": 0.4
# },
# "seuil_rejet": 0.25,
# "poids_resonance": 0.5,
# "poids_experience": 0.35,
# "poids_affect": 0.15
#
# → Gem.from_file() lit ces champs via g.get("resonances", {...})
#   La classe Gem existante est étendue sans rupture.
# ============================================================

# ============================================================
# ADAPTATEUR ParseResult → StructuredIntent
# ============================================================

class ParseResultAdapter:
    """
    Convertit un ParseResult (sorti de IntentParser)
    en StructuredIntent (consommé par CognitionCore._cognize).
    """

    @staticmethod
    def to_intent(result: ParseResult,
                  conversation_id: str,
                  speaker: str,
                  text: str,
                  SourceInfo, SourceWeight, Attribute,
                  StructuredIntent) -> "StructuredIntent":
        """
        result          : ParseResult de nlp_parser
        conversation_id : identifiant de la conversation courante
        speaker         : identifiant du locuteur
        text            : texte brut original (conservé en attribut)
        """
        intent_id = f"intent_{uuid.uuid4().hex[:8]}"
        source = SourceInfo(type=SourceWeight.OBSERVATION,
                            confidence=result.confidence)

        # Attributs de base
        attributes = {
            "text": Attribute(
                type="string",
                value=text,
                source=source
            )
        }

        # Entités extraites → attributs typés
        for slot_name, slot_val in result.entities.items():
            if slot_name.endswith("_resolved"):
                continue  # métadonnée interne

            # Typage automatique
            if isinstance(slot_val, dict):
                attr_type = "object"
            elif isinstance(slot_val, (int, float)):
                attr_type = "number"
            else:
                attr_type = "string"

            attributes[slot_name] = Attribute(
                type=attr_type,
                value=slot_val,
                source=source
            )

        # Entités NER brutes → attribut séparé pour traçabilité
        if result.raw_entities:
            attributes["_ner"] = Attribute(
                type="list",
                value=result.raw_entities,
                source=source
            )

        # Sémantique
        semantic = {
            "intent": result.intent,
            "sub_intent": result.sub_intent,
            "type": result.intent,      # compatibilité v10
            "confidence": result.confidence,
            "sentence_type": result.sentence_type,
            "negated": result.negated,
            "parser_version": "spacy_v1"
        }

        # Pattern source
        if result.matched_pattern_id:
            semantic["matched_pattern"] = result.matched_pattern_id

        return StructuredIntent(
            id=intent_id,
            timestamp=time.time(),
            conversation_id=conversation_id,
            speaker=speaker,
            semantic=semantic,
            attributes=attributes
        )


# ============================================================
# COGNITION CORE v11
# ============================================================

class CognitionCore:
    """
    Cœur cognitif v11.

    Remplace :
    - _text_to_intent  → IntentParser (spaCy + patterns JSON)
    - SentenceBuilder  → TemplateBuilder (templates JSON + FrenchMorphology)

    Interface publique identique à v10.
    """

    def __init__(self, data_path: Path, gem_path: Path,
                 patterns_dir: Path = Path("./patterns"),
                 templates_dir: Path = Path("./templates"),
                 narrative_dir: Path = Path("./narrative")):
        """
        data_path     : répertoire de données persistantes (graphe, index)
        gem_path      : fichier gem.json
        patterns_dir  : répertoire des patterns NLP par domaine
        templates_dir : répertoire des templates de génération par domaine
        narrative_dir : répertoire de la mémoire narrative
        """
        self.data_path = Path(data_path)
        self.data_path.mkdir(parents=True, exist_ok=True)

        # --- Gem ---
        logger.info(f"📖 Chargement du Gem depuis {gem_path}")
        self.gem = Gem.from_file(gem_path)

        # --- Graphe de connaissances ---
        self.graph = KnowledgeGraph(self.data_path / "graph")

        # --- Morphologie française ---
        self.morpho = FrenchMorphology()

        # --- Parseur NLP ---
        logger.info(f"🔬 Initialisation IntentParser (patterns: {patterns_dir})")
        self._parser: Optional[IntentParser] = None
        self._patterns_dir  = Path(patterns_dir)
        self._templates_dir = Path(templates_dir)
        self._init_parser()

        # --- Générateur de texte ---
        self.builder = GrammarBuilder(
            gem=self.gem,
            morpho=self.morpho,
            bases_dir=Path("./bases")
        )

        # --- Contexte ---
        self.current_conversation: Optional[ContextFrame] = None
        self.system_context = SystemContext()

        # --- Queue d'actions sortante (publique) ---
        # Intents actionnables émis ou reçus → consommés par le planificateur externe
        self.action_queue: queue.Queue = queue.Queue()

        # Ensemble des sub_intents actionnables — chargé depuis patterns/actions.json
        self._actionable_intents: Dict[str, Set[str]] = {
            "entrants": set(),
            "sortants": set()
        }
        self._load_actionable_intents(self._patterns_dir / "actions.json")

        # --- Mémoire narrative (entrée externe, lecture isolée) ---
        self.narrative_store = NarrativeStore(
            narrative_dir=Path(narrative_dir),
            gem_id=self.gem.identifiant
        )

        # --- Threads ---
        self._running = False
        self._cooling_thread = None
        self._nightly_thread = None

        logger.info(f"✅ CognitionCore v{__version__} — Gem: {self.gem.nom}")

    # ----------------------------------------------------------
    # INITIALISATION DES NOUVEAUX COMPOSANTS
    # ----------------------------------------------------------

    def _init_parser(self):
        """Initialise l'IntentParser avec tous les domaines disponibles."""
        try:
            self._parser = IntentParser(
                patterns_dir=self._patterns_dir,
                graph=self.graph
            )
            # Activer le LLM fallback seulement si l'option globale est True
            if USE_LLM_FALLBACK:
                llm_config = getattr(self.gem, "llm_fallback", None)
                if llm_config is None:
                    llm_config = {
                        "provider":  "ollama",
                        "model":     "mistral",
                        "threshold": 0.5,
                        "timeout":   5
                    }
                self._parser.enable_llm_fallback(
                    provider  = llm_config.get("provider",  "ollama"),
                    model     = llm_config.get("model",     "mistral"),
                    threshold = llm_config.get("threshold", 0.5),
                    timeout   = llm_config.get("timeout",   5)
                )
            else:
                logger.info("LLM fallback désactivé (USE_LLM_FALLBACK=False)")

        except RuntimeError as e:
            logger.error(f"⚠️  IntentParser non disponible : {e}")
            logger.warning("   → Fallback sur le parseur basique")
            self._parser = None

    def _load_actionable_intents(self, actions_path: Path):
        """
        Charge depuis patterns/actions.json les sub_intents actionnables.
        Si le fichier est absent, les ensembles restent vides.
        """
        if not actions_path.exists():
            logger.warning(f"patterns/actions.json introuvable — action_queue désactivée")
            return
        try:
            with open(actions_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._actionable_intents["entrants"] = set(
                data.get("actionable_sub_intents", {}).get("entrants", [])
            )
            self._actionable_intents["sortants"] = set(
                data.get("actionable_sub_intents", {}).get("sortants", [])
            )
            logger.info(
                f"Actions chargées — entrants: {len(self._actionable_intents['entrants'])}, "
                f"sortants: {len(self._actionable_intents['sortants'])}"
            )
        except Exception as e:
            logger.error(f"Erreur chargement actions.json : {e}")

    def load_knowledge_base(self, name: str, filepath: Path):
        """
        Charge une base de connaissances ET le domaine de patterns/templates
        correspondant si disponible.
        """
        # Chargement graphe (identique v10)
        logger.info(f"📚 Chargement base '{name}' depuis {filepath}")
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        source = SourceInfo(type=SourceWeight.EDUCATIVE)

        for concept_data in data.get("concepts", []):
            concept = Concept(
                id=concept_data.get("id", f"kb_{uuid.uuid4().hex[:8]}"),
                nom=concept_data["nom"],
                nature=ConceptNature(concept_data["nature"]),
                memoire_type=MemoryType(concept_data.get("memoire_type", "permanent")),
                aliases=set(concept_data.get("aliases", []))
            )
            self.graph.add_concept(concept)

            for rel in concept_data.get("relations", []):
                self.graph.add_relation(
                    concept.id,
                    RelationType(rel["type"]),
                    rel["cible"],
                    source
                )

            for prop, val in concept_data.get("proprietes", {}).items():
                concept.add_propriete(
                    prop, val["valeur"], val.get("type", "texte"), source
                )

        count = len(data.get("concepts", []))
        logger.info(f"  ✓ {count} concepts chargés")

        # Charger le domaine de patterns correspondant si disponible
        if self._parser:
            pattern_file = self._patterns_dir / f"{name}.json"
            if pattern_file.exists():
                self._parser.load_domain(name)

        # Charger le domaine de templates correspondant si disponible
        template_file = self._templates_dir / f"{name}.json"
        if template_file.exists():
            self.builder.load_domain(name)

    # ----------------------------------------------------------
    # THREADS DE MAINTENANCE (inchangés v10)
    # ----------------------------------------------------------

    def start(self):
        self._running = True
        self._cooling_thread = threading.Thread(
            target=self._cooling_loop, name="cooling", daemon=True
        )
        self._cooling_thread.start()
        self._nightly_thread = threading.Thread(
            target=self._nightly_loop, name="nightly", daemon=True
        )
        self._nightly_thread.start()
        self.narrative_store.start()
        logger.info("✅ CognitionCore démarré")

    def stop(self):
        self._running = False
        if self._cooling_thread:
            self._cooling_thread.join(timeout=5)
        if self._nightly_thread:
            self._nightly_thread.join(timeout=5)
        self.narrative_store.stop()
        logger.info("✅ CognitionCore arrêté")

    def _cooling_loop(self):
        while self._running:
            time.sleep(CONFIG["cooling_interval_hours"] * 3600)
            self.graph.cool_down()

    def _nightly_loop(self):
        while self._running:
            now = datetime.now()
            if now.hour == CONFIG["nightly_hour"] and now.minute < 5:
                # Consolidation du graphe de connaissances
                self.graph.consolidate()
                # Archivage de la mémoire narrative du jour
                self.narrative_store.archive_today()
                time.sleep(3600)
            time.sleep(60)

    # ----------------------------------------------------------
    # POINT D'ENTRÉE (interface identique v10)
    # ----------------------------------------------------------

    def process(self, input_data: Union[str, Dict, "StructuredIntent"],
                input_type: str = "text",
                output_type: str = "intent") -> Union["StructuredIntent", str, None]:
        """
        Point d'entrée unique.

        input_type  : "text" | "intent"
        output_type : "intent" | "text"
        """
        # 1. Normaliser en intent
        if input_type == "text" and isinstance(input_data, str):
            intent = self._text_to_intent(input_data)
        elif input_type == "intent":
            if isinstance(input_data, StructuredIntent):
                intent = input_data
            elif isinstance(input_data, dict):
                intent = self._dict_to_intent(input_data)
            else:
                raise ValueError("input_type=intent mais input_data invalide")
        else:
            raise ValueError(f"input_type={input_type} non supporté")

        # 2. Traitement cognitif (inchangé v10)
        response_intent = self._cognize(intent)

        # 3. Sortie
        if output_type == "intent":
            return response_intent
        elif output_type == "text":
            return self.builder.build(response_intent, self.current_conversation)
        else:
            raise ValueError(f"output_type={output_type} non supporté")

    # ----------------------------------------------------------
    # TEXTE → INTENT (nouveau : via IntentParser)
    # ----------------------------------------------------------

    def _text_to_intent(self, text: str) -> "StructuredIntent":
        """
        Convertit un texte en StructuredIntent via IntentParser (spaCy).
        Fallback sur l'ancienne méthode basique si spaCy indisponible.
        """
        # Créer ou récupérer le contexte de conversation
        if not self.current_conversation or self.current_conversation.is_expired():
            self.current_conversation = ContextFrame(
                conversation_id=f"conv_{uuid.uuid4().hex[:8]}"
            )

        if self._parser is not None:
            # === NOUVEAU : IntentParser spaCy ===
            parse_result = self._parser.parse(
                text,
                context_frame=self.current_conversation,
                conversation_id=self.current_conversation.conversation_id,
                speaker=self.current_conversation.who or "unknown"
            )

            intent = ParseResultAdapter.to_intent(
                result=parse_result,
                conversation_id=self.current_conversation.conversation_id,
                speaker=self.current_conversation.who or "unknown",
                text=text,
                SourceInfo=SourceInfo,
                SourceWeight=SourceWeight,
                Attribute=Attribute,
                StructuredIntent=StructuredIntent
            )

        else:
            # === FALLBACK : parseur basique v10 ===
            intent = self._text_to_intent_fallback(text)

        # Mise à jour du contexte
        self._update_context_from_intent(intent)

        return intent

    def _update_context_from_intent(self, intent: "StructuredIntent"):
        """Met à jour le ContextFrame depuis un intent parsé."""
        if not self.current_conversation:
            return

        updates = {"history": [intent.id]}

        # Mettre à jour le sujet courant si une personne a été détectée
        if "personne" in intent.attributes:
            person_val = intent.attributes["personne"].value
            if isinstance(person_val, str):
                subjects = list(self.current_conversation.subjects)
                if person_val not in subjects:
                    subjects.append(person_val)
                updates["subjects"] = subjects[-10:]  # garder les 10 derniers

        self.current_conversation.update(**updates)

    def _text_to_intent_fallback(self, text: str) -> "StructuredIntent":
        """Parseur basique de secours (v10 original)."""
        intent_id = f"intent_{uuid.uuid4().hex[:8]}"
        text_lower = text.lower()

        if text_lower.endswith("?"):
            if "heure" in text_lower:
                intent_type, sub_intent = "question", "heure_actuelle"
            elif "qui" in text_lower:
                intent_type, sub_intent = "question", "identite_personne"
            elif "saison" in text_lower:
                intent_type, sub_intent = "question", "saison_actuelle"
            else:
                intent_type, sub_intent = "question", "general"
        elif any(w in text_lower for w in ["bonjour", "salut", "coucou", "hello"]):
            intent_type, sub_intent = "social", "salutation"
        elif any(w in text_lower for w in ["au revoir", "bye", "tchao"]):
            intent_type, sub_intent = "social", "conge"
        elif "merci" in text_lower:
            intent_type, sub_intent = "social", "remerciement"
        else:
            intent_type, sub_intent = "information", "statement"

        source = SourceInfo(type=SourceWeight.OBSERVATION)
        return StructuredIntent(
            id=intent_id,
            timestamp=time.time(),
            conversation_id=self.current_conversation.conversation_id,
            speaker=self.current_conversation.who or "unknown",
            semantic={
                "intent": intent_type,
                "sub_intent": sub_intent,
                "type": intent_type,
                "confidence": 0.6,
                "parser_version": "fallback_v10"
            },
            attributes={
                "text": Attribute(type="string", value=text, source=source)
            }
        )

    def _dict_to_intent(self, data: Dict) -> "StructuredIntent":
        """Reconstruit un StructuredIntent depuis un dict (identique v10)."""
        return StructuredIntent(
            id=data.get("id", f"intent_{uuid.uuid4().hex[:8]}"),
            timestamp=data.get("timestamp", time.time()),
            conversation_id=data.get("conversation_id", ""),
            speaker=data.get("speaker", "unknown"),
            semantic=data.get("semantic", {}),
            attributes={
                k: Attribute(
                    type=v["type"],
                    value=v["value"],
                    source=SourceInfo(type=SourceWeight(v.get("source", 0.9)))
                ) for k, v in data.get("attributes", {}).items()
            },
            signatures=data.get("signatures", {})
        )

    # ----------------------------------------------------------
    # ENTRÉE NARRATIVE PUBLIQUE
    # ----------------------------------------------------------

    def push_narrative(self, intent, source: str = "external"):
        """
        Reçoit un intent narratif depuis l'extérieur.
        Fire-and-forget — non bloquant.
        L'entité n'a pas à répondre, c'est une observation pure.

        source : qui envoie ("perception", "planificateur", "embodiment", etc.)
        """
        self.narrative_store.push(intent, source)

    # ----------------------------------------------------------
    # COGNIZE v12
    # ----------------------------------------------------------

    def _cognize(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Traitement cognitif principal.

        Nouveautés v12 :
        - Intent entrant actionable → aussi dans action_queue
        - Intent question/memoire_narrative → lecture narrative isolée
        - Intent sortant actionable → aussi dans action_queue
        """
        # Identification par signature
        if intent.signatures:
            if "voice" in intent.signatures:
                person = self.graph.find_by_signature_vocale(
                    intent.signatures["voice"]
                )
                if person:
                    intent.speaker = person.id
            if "face" in intent.signatures:
                person = self.graph.find_by_signature_visage(
                    intent.signatures["face"]
                )
                if person:
                    intent.speaker = person.id

        # Intent entrant actionable → action_queue
        sub_in = intent.semantic.get("sub_intent", "")
        if sub_in in self._actionable_intents["entrants"]:
            self.action_queue.put(intent)
            logger.debug(f"Intent entrant actionable routé : {sub_in}")

        # Routage cognitif
        intent_type = intent.semantic.get("type", "")

        if intent_type in (IntentType.QUESTION, "question"):
            if sub_in == "memoire_narrative":
                response = self._query_narrative(intent)
            elif sub_in == "preference":
                response = self._answer_preference(intent)
            else:
                response = self._answer_question(intent)
        elif intent_type in (IntentType.INFORMATION, "information"):
            if sub_in == "preference":
                response = self._update_preference(intent)
            else:
                response = self._store_information(intent)
        elif intent_type in (IntentType.SOCIAL, "social"):
            response = self._social_response(intent)
        elif intent_type in (IntentType.META, "meta"):
            response = self._meta_response(intent)
        else:
            response = self._default_response(intent)

        # Intent sortant actionable → action_queue
        sub_out = response.semantic.get("sub_intent", "")
        if sub_out in self._actionable_intents["sortants"]:
            self.action_queue.put(response)
            logger.debug(f"Intent sortant actionable routé : {sub_out}")

        return response

    def _query_narrative(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Interroge la mémoire narrative en lecture isolée.
        Les intents retournés n'entrent pas dans le graphe principal.
        """
        # Extraire les paramètres temporels depuis les attributs
        annee  = None
        mois   = None
        embodiment = None

        time_attr = intent.attributes.get("time") or intent.attributes.get("date")
        if time_attr:
            try:
                dt = datetime.fromisoformat(str(time_attr.value))
                annee = dt.year
                mois  = dt.month
            except (ValueError, TypeError):
                pass

        emb_attr = intent.attributes.get("embodiment")
        if emb_attr:
            embodiment = emb_attr.value

        sub_intent_filtre = intent.attributes.get("sub_intent_filtre")
        filtre = sub_intent_filtre.value if sub_intent_filtre else None

        # Lecture isolée
        entries = self.narrative_store.query(
            annee=annee,
            mois=mois,
            sub_intent=filtre,
            embodiment=embodiment,
            limit=50
        )

        return self._make_response(
            intent, "reponse", "memoire_narrative",
            confidence=1.0,
            attributes={
                "entries": Attribute(
                    type="list",
                    value=entries,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "count": Attribute(
                    type="number",
                    value=len(entries),
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    def _answer_preference(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Répond à une question de préférence.

        Interroge le graphe pour l'état de préférence stocké sur le concept.
        Si absent → NE_SAIT_PAS.
        Si présent → retourne l'état avec sa justification si disponible.

        NOTE v13 : le calcul de valorisation (résonance Gem + expériences
        narratives + affect courant) est réservé pour PreferenceEngine.
        Ici on lit uniquement ce qui est déjà stocké dans le graphe.
        """
        # Extraire le sujet de la préférence
        sujet_attr = (intent.attributes.get("sujet")
                      or intent.attributes.get("concept")
                      or intent.attributes.get("personne")
                      or intent.attributes.get("objet"))

        if not sujet_attr:
            # Tenter d'extraire depuis le texte brut
            text = intent.attributes.get("text",
                   Attribute(type="string", value="")).value
            sujet_nom = self._extract_preference_subject(str(text))
        else:
            sujet_nom = str(sujet_attr.value)

        if not sujet_nom:
            return self._make_response(intent, "clarification", "general")

        # Chercher le concept dans le graphe
        concept = self.graph.get(sujet_nom)

        if not concept:
            # Concept inconnu → NE_SAIT_PAS
            return self._make_response(
                intent, "reponse", "preference",
                confidence=0.9,
                attributes={
                    "sujet": Attribute(
                        type="string", value=sujet_nom,
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    ),
                    "etat": Attribute(
                        type="preference_state",
                        value=PreferenceState.NE_SAIT_PAS.value,
                        source=SourceInfo(type=SourceWeight.SELF)
                    ),
                    "justification": Attribute(
                        type="string",
                        value=f"Je ne connais pas encore {sujet_nom}.",
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        # Lire l'état de préférence stocké sur le concept
        pref_prop = concept.proprietes.get("preference_state")

        if not pref_prop:
            # Concept connu mais jamais évalué → NE_SAIT_PAS
            etat = PreferenceState.NE_SAIT_PAS
            justification = (f"Je connais {concept.nom} mais "
                             f"je n'ai pas encore d'avis clair.")
        else:
            etat = PreferenceState(pref_prop.valeur)
            # Lire la justification si stockée
            just_prop = concept.proprietes.get("preference_justification")
            justification = (just_prop.valeur if just_prop
                             else self._build_justification(concept, etat))

        return self._make_response(
            intent, "reponse", "preference",
            confidence=0.9,
            attributes={
                "sujet": Attribute(
                    type="string", value=concept.nom,
                    source=SourceInfo(type=SourceWeight.OBSERVATION)
                ),
                "etat": Attribute(
                    type="preference_state", value=etat.value,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "justification": Attribute(
                    type="string", value=justification,
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    def _update_preference(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Met à jour ou crée l'état de préférence pour un concept.

        Peut être appelé :
        - par une déclaration de l'interlocuteur ("tu aimes les chats ?")
          après que l'entité a répondu et confirmé
        - par une expérience significative signalée en intent entrant
        - par le PreferenceEngine (quand il sera branché)

        Règles :
        - NE_SAIT_PAS peut évoluer vers n'importe quel état
        - INDIFFERENT peut évoluer mais résiste davantage
        - AIME / AIME_PAS évoluent lentement (stabilité minimale RG7)
        - Un état ne change pas sans source identifiable (RG7)
        """
        sujet_attr = (intent.attributes.get("sujet")
                      or intent.attributes.get("concept")
                      or intent.attributes.get("personne"))

        etat_attr  = intent.attributes.get("etat")
        just_attr  = intent.attributes.get("justification")

        if not sujet_attr or not etat_attr:
            return self._make_response(intent, "clarification", "general")

        sujet_nom = str(sujet_attr.value)
        nouvel_etat_str = str(etat_attr.value)

        # Valider l'état
        try:
            nouvel_etat = PreferenceState(nouvel_etat_str)
        except ValueError:
            logger.warning(f"État de préférence invalide : {nouvel_etat_str}")
            return self._make_response(intent, "clarification", "general")

        # Récupérer ou créer le concept
        concept = self.graph.get(sujet_nom)
        if not concept:
            concept = self.graph.get_or_create(
                sujet_nom,
                ConceptNature.CATEGORIE,
                MemoryType.EPISODIQUE,
                SourceInfo(type=SourceWeight.OBSERVATION)
            )

        source = SourceInfo(
            type=SourceWeight.SELF,
            speaker="system",
            confidence=intent.semantic.get("confidence", 0.8)
        )

        # Lire l'état actuel
        etat_actuel_prop = concept.proprietes.get("preference_state")
        etat_actuel = (PreferenceState(etat_actuel_prop.valeur)
                       if etat_actuel_prop else None)

        # Vérifier la cohérence (RG7 — stabilité minimale)
        if etat_actuel and not self._preference_transition_allowed(
                etat_actuel, nouvel_etat, intent):
            logger.debug(
                f"Transition {etat_actuel} → {nouvel_etat} "
                f"refusée pour {sujet_nom} (stabilité)"
            )
            return self._make_response(
                intent, "acknowledge", "preference_stable"
            )

        # Écrire le nouvel état
        concept.add_propriete(
            "preference_state",
            nouvel_etat.value,
            "preference_state",
            source
        )

        # Écrire la justification si fournie
        if just_attr:
            concept.add_propriete(
                "preference_justification",
                str(just_attr.value),
                "texte",
                source
            )

        # Horodater l'évolution
        concept.add_propriete(
            "preference_updated_at",
            datetime.now().isoformat(),
            "datetime",
            source
        )

        logger.info(
            f"Préférence mise à jour : {sujet_nom} → {nouvel_etat.value}"
        )

        return self._make_response(
            intent, "acknowledge", "preference_updated",
            attributes={
                "sujet": Attribute(
                    type="string", value=sujet_nom,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "etat": Attribute(
                    type="preference_state", value=nouvel_etat.value,
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    # ----------------------------------------------------------
    # Helpers préférences
    # ----------------------------------------------------------

    @staticmethod
    def _extract_preference_subject(text: str) -> Optional[str]:
        """
        Extrait le sujet d'une question de préférence depuis le texte brut.
        Heuristique simple — spaCy NER prendra le relais quand disponible.
        """
        patterns = [
            r"(?:aimes?[-\s]tu|tu aimes?|est[-\s]ce que tu aimes?)\s+([\w\s\-]+?)(?:\s*\?|$)",
            r"(?:qu(?:e|'est[-\s]ce que) tu penses? de)\s+([\w\s\-]+?)(?:\s*\?|$)",
            r"(?:ton avis sur|ta préférence pour)\s+([\w\s\-]+?)(?:\s*\?|$)",
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return None

    @staticmethod
    def _preference_transition_allowed(
            actuel: "PreferenceState",
            nouveau: "PreferenceState",
            intent: "StructuredIntent") -> bool:
        """
        Vérifie si la transition d'état est autorisée.

        Règles de stabilité (RG7) :
        - NE_SAIT_PAS → tout : toujours autorisé
        - INDIFFERENT  → tout : autorisé avec source OBSERVATION ou SELF
        - NEUTRE       → AIME / AIME_PAS : autorisé
        - AIME         → AIME_PAS / NEUTRE : autorisé seulement si
                         source forte (OBSERVATION) ou expérience significative
        - AIME_PAS     → AIME / NEUTRE : idem
        """
        if actuel == PreferenceState.NE_SAIT_PAS:
            return True

        if actuel == PreferenceState.INDIFFERENT:
            return True

        if actuel == PreferenceState.NEUTRE:
            return True

        # AIME ou AIME_PAS — transition exige une source forte
        source_weight = intent.semantic.get("source_weight",
                        SourceWeight.OBSERVATION.value)
        return float(source_weight) >= SourceWeight.OBSERVATION.value

    def _build_justification(self, concept, etat: "PreferenceState") -> str:
        """
        Construit une justification minimale depuis les relations du graphe.
        Version squelette — sera enrichie par PreferenceEngine.
        """
        if etat == PreferenceState.NE_SAIT_PAS:
            return f"Je ne connais pas encore assez {concept.nom}."

        if etat == PreferenceState.INDIFFERENT:
            return f"{concept.nom.capitalize()} ne m'évoque rien de particulier."

        if etat == PreferenceState.NEUTRE:
            return (f"J'ai des avis partagés sur {concept.nom} — "
                    f"certains aspects m'attirent, d'autres moins.")

        # Chercher des caractéristiques dans le graphe
        carac = [
            r.cible for r in concept.get_relations()
            if hasattr(r, "type") and
            str(r.type) in ("a_pour_caracteristique", "RelationType.A_POUR_CARACTERISTIQUE")
        ]

        if carac and etat == PreferenceState.AIME:
            carac_str = ", ".join(carac[:2])
            return f"J'aime {concept.nom} — notamment pour {carac_str}."

        if carac and etat == PreferenceState.AIME_PAS:
            return f"{concept.nom.capitalize()} ne me convient pas vraiment."

        return (f"C'est mon ressenti pour {concept.nom}.")
        """
        Répond à une question.
        Gère les nouveaux sub_intents issus des patterns spaCy.
        """
        sub = intent.semantic.get("sub_intent", "")

        # ── Heure ──
        if sub in ("heure_actuelle", "time"):
            now = datetime.now()
            return self._make_response(
                intent, "reponse", "heure_actuelle",
                attributes={
                    "time": Attribute(
                        type="datetime",
                        value=now.isoformat(),
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Saison ──
        elif sub in ("saison_actuelle", "saison"):
            saison = self._get_saison()
            return self._make_response(
                intent, "reponse", "saison_actuelle",
                attributes={
                    "saison": Attribute(
                        type="string",
                        value=saison,
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Date ──
        elif sub in ("date_actuelle", "date"):
            now = datetime.now()
            return self._make_response(
                intent, "reponse", "date_actuelle",
                attributes={
                    "time": Attribute(
                        type="datetime",
                        value=now.isoformat(),
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Identité personne ──
        elif sub in ("identite_personne", "person"):
            return self._answer_person_question(intent)

        # ── Identité propre ──
        elif sub == "identite_self":
            return self._make_response(
                intent, "reponse", "identite_self",
                attributes={
                    "nom": Attribute(
                        type="string",
                        value=self.gem.nom,
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        # ── Question générale sans pattern matchant ──
        return self._make_response(intent, "clarification", "general")

    def _answer_person_question(self, intent: "StructuredIntent") -> "StructuredIntent":
        """Recherche une personne dans le graphe et répond."""
        # Récupérer le nom depuis le slot ou le texte brut
        person_attr = intent.attributes.get("personne")
        name = person_attr.value if person_attr else None

        if not name:
            # Tenter d'extraire depuis le texte
            text = intent.attributes.get("text", Attribute(type="string", value="")).value
            match = re.search(
                r"(?:qui est|c'est qui|tu connais)\s+([\w\s\-]+?)(?:\s*\?|$)",
                str(text), re.IGNORECASE
            )
            name = match.group(1).strip() if match else None

        if name:
            concept = self.graph.get(name)
            if concept:
                return self._make_response(
                    intent, "reponse", "person_info",
                    confidence=0.9,
                    attributes={
                        "person": Attribute(
                            type="object",
                            value={
                                "name": concept.nom,
                                "relations": [r.type.value for r in concept.get_relations()]
                            },
                            source=SourceInfo(type=SourceWeight.OBSERVATION)
                        )
                    }
                )

        # Personne inconnue → demande de clarification
        return self._make_response(
            intent, "clarification", "personne_inconnue",
            confidence=0.8,
            attributes={
                "personne": Attribute(
                    type="string",
                    value=name or "cette personne",
                    source=SourceInfo(type=SourceWeight.OBSERVATION)
                )
            }
        )

    def _store_information(self, intent: "StructuredIntent") -> "StructuredIntent":
        """Stocke une information dans le graphe (identique v10)."""
        return self._make_response(intent, "acknowledge", "information")

    def _social_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Répond aux échanges sociaux.
        Passe directement le sub_intent au builder (salutation, conge, etc.).
        """
        sub = intent.semantic.get("sub_intent", "salutation")

        # Transmettre le destinataire si disponible
        extra_attrs = {}
        if "destinataire" in intent.attributes:
            extra_attrs["destinataire"] = intent.attributes["destinataire"]

        return self._make_response(
            intent, "social", sub,
            confidence=1.0,
            attributes=extra_attrs
        )

    def _meta_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        """Répond aux questions sur le système lui-même."""
        sub = intent.semantic.get("sub_intent", "")

        if sub == "identite_self":
            return self._make_response(
                intent, "reponse", "identite_self",
                attributes={
                    "nom": Attribute(
                        type="string",
                        value=self.gem.nom,
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        return self._default_response(intent)

    def _default_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        return self._make_response(intent, "acknowledge", "default", confidence=0.7)

    # ----------------------------------------------------------
    # HELPER : fabrication d'un intent de réponse
    # ----------------------------------------------------------

    def _make_response(self, source_intent: "StructuredIntent",
                       intent_type: str, sub_intent: str,
                       confidence: float = 0.95,
                       attributes: Dict = None) -> "StructuredIntent":
        """Fabrique un StructuredIntent de réponse de façon concise."""
        return StructuredIntent(
            id=f"resp_{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            conversation_id=source_intent.conversation_id,
            speaker="system",
            semantic={
                "intent": intent_type,
                "sub_intent": sub_intent,
                "type": intent_type,
                "confidence": confidence
            },
            attributes=attributes or {},
            in_response_to=source_intent.id
        )

    # ----------------------------------------------------------
    # UTILITAIRES
    # ----------------------------------------------------------

    @staticmethod
    def _get_saison() -> str:
        """Retourne la saison courante."""
        now = datetime.now()
        m, j = now.month, now.day
        if (m == 3 and j >= 20) or m in (4, 5) or (m == 6 and j < 21):
            return "printemps"
        if (m == 6 and j >= 21) or m in (7, 8) or (m == 9 and j < 22):
            return "été"
        if (m == 9 and j >= 22) or m in (10, 11) or (m == 12 and j < 21):
            return "automne"
        return "hiver"


# ============================================================
# POINT D'ENTRÉE (identique v10)
# ============================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s.%(msecs)03d %(levelname)-8s [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )

    data_path = Path("./data")
    gem_path = Path("./gem.json")
    bases_path = Path("./bases")

    # Vérifier que gem.json existe (sinon le créer comme en v10)
    if not gem_path.exists():
        example_gem = {
            "gem": {
                "identifiant": "shirka_demo",
                "nom": "Shirka",
                "date_naissance": datetime.now().isoformat(),
                "version": 1,
                "tempo_base": 0.65, "intensite_base": 0.7,
                "grace": 0.5, "reactivite": 0.8,
                "curiosite_mots": 0.8, "curiosite_verbes": 0.5,
                "curiosite_personnes": 0.9, "curiosite_lieux": 0.8,
                "curiosite_faits": 0.7,
                "affinites_litterature": {
                    "roman": 0.8, "poesie": 0.4, "theatre": 0.6, "essai": 0.7
                },
                "duree_memoire_litterature": 30,
                "duree_memoire_episodique": 90,
                "duree_memoire_sociale": 365,
                "style_prefere": "narratif",
                "seuil_curiosite": 0.7,
                "signature_type": "sha256",
                "signature_valeur": "demo"
            }
        }
        with open(gem_path, "w", encoding="utf-8") as f:
            json.dump(example_gem, f, indent=2)

    # Initialiser
    core = CognitionCore(
        data_path=data_path,
        gem_path=gem_path,
        patterns_dir=Path("./patterns"),
        templates_dir=Path("./templates")
    )

    # Charger les bases de connaissances
    temps_path = bases_path / "temps.json"
    if temps_path.exists():
        core.load_knowledge_base("temps", temps_path)

    core.start()

    # Tests
    test_phrases = [
        "bonjour",
        "c'est quelle saison ?",
        "quelle heure est-il ?",
        "il est quelle heure ?",          # → doit matcher comme v10 ne matchait pas
        "qui est Paul ?",
        "qui es-tu ?",                    # → meta / identite_self
        "salut tout le monde !",          # → social / salutation malgré "tout le monde"
        "tu peux me dire l'heure ?",      # → question / heure_actuelle
        "merci beaucoup",
        "au revoir",
        "bonne soirée"
    ]

    print("\n" + "="*60)
    print(f" TESTS — CognitionCore v{__version__}")
    print("="*60)

    for phrase in test_phrases:
        print(f"\n📥 '{phrase}'")

        try:
            intent = core.process(phrase, input_type="text", output_type="intent")
            parser_ver = intent.semantic.get("parser_version", "?")
            print(f"  Intent : {intent.semantic['intent']}/{intent.semantic['sub_intent']}"
                  f"  (conf={intent.semantic['confidence']:.2f}, parser={parser_ver})")

            texte = core.process(intent, input_type="intent", output_type="text")
            print(f"  Réponse: {texte}")

        except Exception as e:
            print(f"  ⚠️  Erreur : {e}")

    print("\n" + "="*60)
    print(" STATISTIQUES")
    print("="*60)
    print(f"Concepts en RAM     : {len(core.graph.ram_cache)}")
    if core._parser:
        print(f"Domaines patterns   : {core._parser.loaded_domains}")
    print(f"Domaines templates  : {core.builder.loaded_domains}")

    core.stop()
