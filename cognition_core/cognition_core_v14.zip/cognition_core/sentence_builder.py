"""
sentence_builder.py — Générateur de texte par grammaire de réécriture
Version 2.0.0

Remplace TemplateBuilder (v1) dans cognition_core.
Interface publique identique : GrammarBuilder.build(intent, context_frame)

Changements vs v1 :
  - Plus de templates JSON : génération par règles grammaticales
  - GrammarEngine pilote la construction phrase par phrase
  - AffectiveState construit depuis le Gem + état affectif externe injecté
  - Registre inféré depuis ContextFrame ou Gem
  - Fallbacks conservés pour les cas non couverts

Dépendances :
  grammar_engine.py   (GrammarEngine, AffectiveState)
  french_morphology.py (FrenchMorphology)

Usage (identique v1) :
    builder = GrammarBuilder(gem, morpho, bases_dir="./bases")
    texte   = builder.build(intent, context_frame)

    # Injection d'état affectif externe (depuis couche affective)
    builder.set_affect(AffectiveState(valence=0.6, arousal=0.4, dominance=0.7))
"""

import logging
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

from grammar_engine import GrammarEngine, AffectiveState

logger = logging.getLogger("GrammarBuilder")


# ============================================================
# TRADUCTEUR Intent → Sémantique GrammarEngine
# ============================================================

class IntentSemanticBridge:
    """
    Traduit un StructuredIntent en dict sémantique
    consommable par GrammarEngine.generate().

    Chaque méthode correspond à un couple (intent_type, sub_intent)
    et retourne (intent_type_grammar, semantic_dict).
    """

    # Correspondance sub_intent → intent_type GrammarEngine
    INTENT_TYPE_MAP = {
        # Questions
        "heure_actuelle":     "question",
        "saison_actuelle":    "question",
        "date_actuelle":      "question",
        "identite_personne":  "question",
        "identite_self":      "question",
        "general":            "question",
        # Réponses
        "heure_actuelle_rep": "assertion",
        "saison_actuelle_rep":"assertion",
        "date_actuelle_rep":  "assertion",
        "person_info":        "assertion",
        "identite_self_rep":  "assertion",
        # Affectif
        "salutation":         "reponse_affective",
        "conge":              "reponse_affective",
        "remerciement":       "reponse_affective",
        "excuse":             "reponse_affective",
        "accord":             "reponse_affective",
        "desaccord":          "reponse_affective",
        "surprise":           "reponse_affective",
        # Acquittement
        "information":        "assertion",
        "default":            "assertion",
    }

    @classmethod
    def translate(cls, intent) -> tuple:
        """
        Retourne (grammar_intent_type, semantic_dict) depuis un StructuredIntent.
        """
        intent_type = intent.semantic.get("type", "")
        sub_intent  = intent.semantic.get("sub_intent", "")

        # --- RÉPONSES À DES QUESTIONS ---

        if intent_type in ("reponse", "assertion"):

            if sub_intent == "heure_actuelle":
                return cls._sem_heure(intent)

            if sub_intent == "saison_actuelle":
                return cls._sem_saison(intent)

            if sub_intent == "date_actuelle":
                return cls._sem_date(intent)

            if sub_intent in ("person_info", "identite_self_rep"):
                return cls._sem_personne(intent)

            # Acquittement générique
            return ("assertion", {
                "sujet": "je",
                "predicat": "etre",
                "attribut_type": "adjectif",
                "attribut_valeur": "d'accord",
                "sujet_genre": "masc",
                "sujet_nombre": "sing"
            })

        # --- QUESTIONS ÉMISES PAR L'ENTITÉ ---

        if intent_type == "question":

            if sub_intent == "heure_actuelle":
                return ("question", {
                    "question_type": "directe",
                    "mot_interrogatif": "quelle heure",
                    "sujet": "il",
                    "predicat": "etre"
                })

            if sub_intent == "saison_actuelle":
                return ("question", {
                    "question_type": "directe",
                    "mot_interrogatif": "quelle saison",
                    "sujet": "on",
                    "predicat": "etre"
                })

            if sub_intent in ("identite_personne", "general"):
                return cls._sem_question_generale(intent)

        # --- SOCIAL ET AFFECTIF ---

        if intent_type == "social":
            return cls._sem_social(intent, sub_intent)

        # --- CLARIFICATION ---

        if intent_type == "clarification":
            return cls._sem_clarification(intent, sub_intent)

        # --- ACKNOWLEDGE / DEFAUT ---

        return ("assertion", {
            "sujet": "je",
            "predicat": "etre",
            "attribut_type": "adjectif",
            "attribut_valeur": "d'accord",
            "sujet_genre": "masc",
            "sujet_nombre": "sing"
        })

    # ----------------------------------------------------------
    # Helpers sémantiques
    # ----------------------------------------------------------

    @classmethod
    def _sem_heure(cls, intent) -> tuple:
        time_attr = intent.attributes.get("time")
        if time_attr:
            try:
                dt = datetime.fromisoformat(str(time_attr.value))
            except (ValueError, TypeError):
                dt = datetime.now()
        else:
            dt = datetime.now()

        return ("assertion", {
            "sujet": "il",
            "predicat": "etre",
            "attribut_type": "heure",
            "attribut_valeur": dt
        })

    @classmethod
    def _sem_saison(cls, intent) -> tuple:
        saison_attr = intent.attributes.get("saison")
        saison = saison_attr.value if saison_attr else _saison_actuelle()

        return ("assertion", {
            "sujet": "nous",
            "predicat": "etre",
            "attribut_type": "saison",
            "attribut_valeur": saison
        })

    @classmethod
    def _sem_date(cls, intent) -> tuple:
        time_attr = intent.attributes.get("time")
        if time_attr:
            try:
                dt = datetime.fromisoformat(str(time_attr.value))
            except (ValueError, TypeError):
                dt = datetime.now()
        else:
            dt = datetime.now()

        return ("assertion", {
            "sujet": "nous",
            "predicat": "etre",
            "attribut_type": "date",
            "attribut_valeur": dt
        })

    @classmethod
    def _sem_personne(cls, intent) -> tuple:
        person_attr = intent.attributes.get("person") or intent.attributes.get("personne")
        nom_attr    = intent.attributes.get("nom")

        if nom_attr:
            # Identité propre de l'entité
            return ("assertion", {
                "sujet": "je",
                "predicat": "etre",
                "attribut_type": "nom",
                "attribut_valeur": nom_attr.value,
                "attribut_genre": "masc",
                "attribut_nombre": "sing"
            })

        if person_attr:
            name = person_attr.value
            if isinstance(name, dict):
                name = name.get("name", str(name))
            return ("assertion", {
                "sujet": "je",
                "predicat": "etre",
                "attribut_type": "adjectif",
                "attribut_valeur": f"au courant pour {name}",
                "sujet_genre": "masc",
                "sujet_nombre": "sing"
            })

        return ("assertion", {
            "sujet": "je",
            "predicat": "etre",
            "attribut_type": "adjectif",
            "attribut_valeur": "là",
            "sujet_genre": "masc",
            "sujet_nombre": "sing"
        })

    @classmethod
    def _sem_question_generale(cls, intent) -> tuple:
        text_attr = intent.attributes.get("text")
        text = text_attr.value if text_attr else ""

        return ("question", {
            "question_type": "indirecte",
            "mot_interrogatif": "ce que",
            "sujet": "tu",
            "predicat": "vouloir",
            "verbe_forme": "veux",
            "proposition": text
        })

    # Phrases sociales rituelles par sous-type et registre
    # Le GrammarEngine ne couvre pas les formules de politesse —
    # trop conventionnelles pour être compositionnelles.
    SOCIAL_FIXED = {
        "salutation": {
            "familier": ["Salut !", "Coucou !", "Hé !"],
            "neutre":   ["Bonjour.", "Bonjour !"],
            "soutenu":  ["Bonjour.", "Je vous salue.", "Bien le bonjour."]
        },
        "conge": {
            "familier": ["À bientôt !", "Bye !", "Ciao !"],
            "neutre":   ["Au revoir.", "À bientôt."],
            "soutenu":  ["Au revoir.", "Je vous souhaite une bonne continuation."]
        },
        "remerciement": {
            "familier": ["Pas de souci !", "De rien !", "Avec plaisir !"],
            "neutre":   ["Avec plaisir.", "De rien."],
            "soutenu":  ["Je vous en prie.", "C'est avec plaisir."]
        },
        "excuse": {
            "familier": ["Aucun souci !", "C'est rien !"],
            "neutre":   ["Pas de problème.", "Ce n'est rien."],
            "soutenu":  ["Il n'y a pas de mal.", "Ne vous inquiétez pas."]
        },
        "compliment": {
            "familier": ["Merci !", "Oh, c'est gentil !"],
            "neutre":   ["Merci.", "C'est aimable."],
            "soutenu":  ["Je vous remercie.", "C'est fort aimable."]
        },
    }

    @classmethod
    def _sem_social(cls, intent, sub_intent: str) -> tuple:
        """
        Les formules sociales rituelles sont signalées via un marqueur spécial
        intercepté par GrammarBuilder._handle_social().
        """
        return ("__social_fixed__", {"sub_intent": sub_intent})

    @classmethod
    def _sem_clarification(cls, intent, sub_intent: str) -> tuple:
        """
        Clarifications → question indirecte + mention de l'inconnu.
        """
        personne_attr = intent.attributes.get("personne")
        mot_attr      = intent.attributes.get("word")

        if sub_intent == "personne_inconnue" and personne_attr:
            nom = personne_attr.value
            return ("question", {
                "question_type": "directe",
                "mot_interrogatif": f"qui est {nom}",
                "sujet": "tu",
                "predicat": "savoir",
                "verbe_forme": "sais"
            })

        if sub_intent == "unknown_word" and mot_attr:
            mot = mot_attr.value
            return ("question", {
                "question_type": "indirecte",
                "mot_interrogatif": "ce que signifie",
                "sujet": "tu",
                "predicat": "pouvoir",
                "verbe_forme": "peux",
                "proposition": f"expliquer « {mot} »"
            })

        # Fallback clarification générique
        return ("question", {
            "question_type": "directe",
            "mot_interrogatif": "ce que tu veux dire",
            "sujet": "tu",
            "predicat": "pouvoir",
            "verbe_forme": "peux"
        })


# ============================================================
# CONSTRUCTEUR PRINCIPAL (drop-in pour TemplateBuilder)
# ============================================================

class GrammarBuilder:
    """
    Remplace TemplateBuilder dans CognitionCore.
    Interface publique identique.

    Utilise GrammarEngine (grammaire de réécriture + morphologie)
    au lieu de templates JSON.

    L'état affectif peut être :
      - inféré automatiquement depuis gem.humeur_actuelle
      - injecté explicitement via set_affect() depuis la couche affective
    """

    def __init__(self, gem, morpho,
                 bases_dir: Path = Path("./bases"),
                 knowledge_bases: Dict = None):
        """
        gem            : Gem (personnalité de l'entité)
        morpho         : FrenchMorphology
        bases_dir      : répertoire des fiches de connaissance JSON
        knowledge_bases: dict pré-chargé (optionnel, prioritaire sur bases_dir)
        """
        self.gem   = gem
        self.morpho = morpho

        # Charger les bases de connaissance pour le lexique génératif
        kb = knowledge_bases or {}
        if not kb and bases_dir:
            kb = self._load_bases(Path(bases_dir))

        self.engine = GrammarEngine(
            morpho=morpho,
            knowledge_bases=kb,
            gem=gem
        )

        # État affectif externe (injecté par la couche affective)
        self._external_affect: Optional[AffectiveState] = None

        # Fallbacks pour les cas non couverts par la grammaire
        self._fallbacks = {
            "reponse/defaut":         "D'accord.",
            "question/general":       "Que veux-tu savoir ?",
            "clarification/general":  "Je n'ai pas compris. Peux-tu reformuler ?",
            "social/salutation":      "Bonjour.",
            "social/conge":           "Au revoir.",
            "social/remerciement":    "Avec plaisir.",
            "acknowledge/information":"D'accord.",
            "acknowledge/default":    "D'accord.",
        }

        # Pour compatibilité avec le code appelant load_domain / load_all_domains
        self._loaded_domains: List[str] = list(kb.keys())

        logger.info(f"GrammarBuilder initialisé — {len(kb)} domaines de connaissance")

    # ----------------------------------------------------------
    # Interface publique (identique TemplateBuilder)
    # ----------------------------------------------------------

    def build(self, intent, context_frame=None) -> Optional[str]:
        """Construit un texte complet (mode batch)."""
        register = self._extract_register(context_frame)
        affect   = self._build_affect()

        try:
            grammar_intent_type, semantic = IntentSemanticBridge.translate(intent)
        except Exception as e:
            logger.warning(f"Bridge échoué : {e}")
            return self._fallback(intent)

        if grammar_intent_type == "__social_fixed__":
            return self._handle_social(semantic["sub_intent"], register, affect)

        try:
            text = self.engine.generate(
                intent_type=grammar_intent_type,
                semantic=semantic,
                affect=affect,
                register=register
            )
        except Exception as e:
            logger.error(f"Génération échouée : {e}")
            return self._fallback(intent)

        if not text or len(text.strip()) < 2:
            return self._fallback(intent)

        logger.debug(
            f"build {intent.semantic.get('type')}/{intent.semantic.get('sub_intent')}"
            f" → '{text}'"
        )
        return text

    def build_stream(self, intent, context_frame=None, stream=None):
        """
        Génère et émet les tokens au fil de l'eau dans un ProductionStream.

        Deux queues en sortie :
          stream.token_queue : SpeechToken émis en temps réel → TTS
          stream.text_queue  : str complet livré à la fin → mémoire / log

        Usage :
            stream = builder.build_stream(intent)

            # Thread TTS (consommateur temps réel)
            for token in stream.iter_tokens():
                tts.speak(token)

            # Thread mémoire (bloquant jusqu'à la fin)
            full_text = stream.get_text()

            # Interruption depuis la couche perceptive
            stream.interrupt(InterruptReason.PERCEPTION)
        """
        from production_stream import ProductionStream as PS, InterruptReason

        if stream is None:
            stream = PS()

        register = self._extract_register(context_frame)
        affect   = self._build_affect()

        try:
            grammar_intent_type, semantic = IntentSemanticBridge.translate(intent)
        except Exception as e:
            logger.warning(f"Bridge échoué en stream : {e}")
            self._stream_fallback(intent, stream)
            return stream

        # Formules sociales fixes → tokens synthétiques dans le même canal
        if grammar_intent_type == "__social_fixed__":
            text = self._handle_social(semantic["sub_intent"], register, affect)
            self._stream_text_as_tokens(text, affect, stream)
            return stream

        # Déléguer au moteur — le thread de production est lancé là-dedans
        self.engine.generate_stream(
            intent_type=grammar_intent_type,
            semantic=semantic,
            affect=affect,
            register=register,
            stream=stream
        )
        return stream

    def set_affect(self, affect: AffectiveState):
        """
        Injecte un état affectif externe depuis la couche affective.
        Prioritaire sur l'humeur du Gem.
        """
        self._external_affect = affect
        logger.debug(
            f"Affect injecté : V={affect.valence:.2f} "
            f"A={affect.arousal:.2f} D={affect.dominance:.2f}"
        )

    def clear_affect(self):
        """Réinitialise à l'affect inféré depuis le Gem."""
        self._external_affect = None

    def load_domain(self, domain: str) -> bool:
        """Compatibilité TemplateBuilder — charge une base de connaissance."""
        bases_dir = Path("./bases")
        fp = bases_dir / f"{domain}.json"
        if not fp.exists():
            return False
        kb = self._load_bases(bases_dir, domains=[domain])
        self.engine.update_knowledge(kb)
        if domain not in self._loaded_domains:
            self._loaded_domains.append(domain)
        return True

    def load_all_domains(self):
        """Compatibilité TemplateBuilder."""
        pass  # Déjà chargé dans __init__

    @property
    def loaded_domains(self) -> List[str]:
        return list(self._loaded_domains)

    # ----------------------------------------------------------
    # Helpers internes
    # ----------------------------------------------------------

    def _build_affect(self) -> AffectiveState:
        """
        Construit l'AffectiveState effectif :
          1. État externe injecté (prioritaire)
          2. Humeur du Gem
          3. Neutre par défaut
        """
        if self._external_affect is not None:
            return self._external_affect

        # Construire depuis l'humeur du Gem
        humeur_map = {
            "joyeuse":   AffectiveState( 0.8,  0.7,  0.8),
            "triste":    AffectiveState(-0.7,  0.2,  0.2),
            "anxieuse":  AffectiveState(-0.5,  0.8,  0.2),
            "sereine":   AffectiveState( 0.6,  0.2,  0.7),
            "curieuse":  AffectiveState( 0.4,  0.6,  0.6),
            "en colere": AffectiveState(-0.6,  0.9,  0.7),
            "neutre":    AffectiveState( 0.0,  0.3,  0.6),
        }
        humeur = getattr(self.gem, "humeur_actuelle", "neutre")
        return humeur_map.get(humeur, AffectiveState())

    def _extract_register(self, context_frame) -> str:
        """
        Extrait le registre depuis le ContextFrame,
        ou l'infère depuis le Gem.
        """
        if context_frame and hasattr(context_frame, "register"):
            reg = context_frame.register
            if reg:
                return reg.value if hasattr(reg, "value") else str(reg)

        # Inférence depuis le Gem
        grace     = getattr(self.gem, "grace",     0.5)
        reactivite = getattr(self.gem, "reactivite", 0.5)

        if grace >= 0.7:
            return "soutenu"
        if reactivite >= 0.8:
            return "familier"
        return "neutre"

    def _handle_social(self, sub_intent: str, register: str,
                        affect: AffectiveState) -> str:
        """Sélectionne une formule sociale selon le registre et l'affect."""
        import random
        pool_by_register = IntentSemanticBridge.SOCIAL_FIXED.get(sub_intent, {})
        pool = pool_by_register.get(register) or pool_by_register.get("neutre", ["D'accord."])

        if affect.est_positif and affect.est_active:
            enthousiastes = [p for p in pool if p.endswith("!")]
            if enthousiastes:
                pool = enthousiastes

        return random.choice(pool)

    def _stream_fallback(self, intent, stream):
        """Émet la réponse de fallback comme tokens dans le stream."""
        text = self._fallback(intent)
        self._stream_text_as_tokens(text, self._build_affect(), stream)

    def _stream_text_as_tokens(self, text: str, affect: AffectiveState, stream):
        """
        Émet une chaîne fixe comme SpeechToken synthétiques dans un stream.
        Utilisé pour les formules sociales et les fallbacks.
        Lance un thread pour rester cohérent avec generate_stream().
        """
        import threading
        from grammar_engine import ProsodyEngine, GrammarNode, ProsodyRole

        def _produce():
            try:
                # Construire un arbre minimal pour avoir les rôles
                node = GrammarNode.terminal(text, role=ProsodyRole.NEUTRE)
                prosody = ProsodyEngine()
                for token in prosody.stream(node, affect, text):
                    if stream.interrupted:
                        closing = stream.get_closing_token(
                            token.__class__, ProsodyRole
                        )
                        stream.put_token(closing)
                        break
                    stream.put_token(token)
            except Exception as e:
                logger.error(f"Erreur stream social : {e}")
            finally:
                stream.done()

        t = threading.Thread(target=_produce, daemon=True,
                             name="social-producer")
        t.start()

    def _fallback(self, intent) -> str:
        """Retourne une réponse de secours."""
        intent_type = intent.semantic.get("type", "")
        sub_intent  = intent.semantic.get("sub_intent", "")
        key = f"{intent_type}/{sub_intent}"

        if key in self._fallbacks:
            return self._fallbacks[key]

        # Chercher par préfixe
        for fb_key, fb_text in self._fallbacks.items():
            if key.startswith(fb_key.split("/")[0]):
                return fb_text

        return "D'accord."

    @staticmethod
    def _load_bases(bases_dir: Path,
                    domains: Optional[List[str]] = None) -> Dict:
        """
        Charge les fiches de connaissance depuis bases_dir.
        Retourne un dict nom_concept → données_fiche.
        """
        kb = {}
        if not bases_dir.exists():
            return kb

        pattern = "*.json"
        files = bases_dir.glob(pattern)

        for fp in files:
            if domains and fp.stem not in domains:
                continue
            try:
                with open(fp, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for concept in data.get("concepts", []):
                    kb[concept["nom"]] = concept
            except Exception as e:
                logger.warning(f"Impossible de charger {fp} : {e}")

        logger.info(f"Bases chargées depuis {bases_dir} : {len(kb)} concepts")
        return kb


# ============================================================
# UTILITAIRE
# ============================================================

def _saison_actuelle() -> str:
    now = datetime.now()
    m, j = now.month, now.day
    if (m == 3 and j >= 20) or m in (4, 5) or (m == 6 and j < 21):
        return "printemps"
    if (m == 6 and j >= 21) or m in (7, 8) or (m == 9 and j < 22):
        return "été"
    if (m == 9 and j >= 22) or m in (10, 11) or (m == 12 and j < 21):
        return "automne"
    return "hiver"
