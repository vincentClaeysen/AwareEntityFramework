"""
narrative_store.py — Mémoire narrative de l'entité
Version 1.0.0

Architecture :
  Mémoire immuable, horodatée, structurée en livre/chapitre/section/page.
  Isolée du graphe de connaissances principal.

  Livre     = 1 embodiment  (identifié par gem.identifiant)
  Chapitre  = 1 année
  Section   = 1 mois
  Page 1    = jours 1-15
  Page 2    = jours 16-fin

Flux :
  Entrée  : push(intent)         — fire-and-forget depuis l'extérieur
  Nuit    : archive_today()      — appelé par le cycle nocturne de CognitionCore
  Lecture : query(...)           — retourne une liste d'intents horodatés
                                   sans toucher au graphe principal

Format disque :
  narrative/
    {gem_id}/                    ← livre = embodiment
      {année}/                   ← chapitre
        {mois:02d}/              ← section
          page_1.json.gz         ← jours 1-15
          page_2.json.gz         ← jours 16-fin
    courant/
      today.json                 ← buffer du jour (RAM + disque), effacé après archivage

Immuabilité :
  Une fois archivée, une page n'est jamais modifiée.
  push() n'écrit que dans today.json.
  archive_today() déplace today → page appropriée (append si la page existe déjà).
"""

import gzip
import json
import logging
import queue
import threading
import time
from dataclasses import asdict
from datetime import datetime, date
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("NarrativeStore")


# ============================================================
# ENTRÉE NARRATIVE HORODATÉE
# ============================================================

class NarrativeEntry:
    """
    Enveloppe d'un intent narratif avec horodatage et source.
    Sérialisable en JSON.
    """

    def __init__(self, intent, source: str = "external"):
        """
        intent : StructuredIntent de cognition_core
        source : qui a poussé cet intent ("perception", "planificateur", etc.)
        """
        self.timestamp   = time.time()
        self.iso_time    = datetime.now().isoformat()
        self.source      = source
        self.intent_data = self._serialize_intent(intent)

    @staticmethod
    def _serialize_intent(intent) -> Dict:
        """Sérialise un StructuredIntent en dict JSON-compatible."""
        try:
            d = asdict(intent)
        except Exception:
            # Fallback si asdict échoue (types non supportés)
            d = {
                "id":              getattr(intent, "id", ""),
                "timestamp":       getattr(intent, "timestamp", time.time()),
                "conversation_id": getattr(intent, "conversation_id", ""),
                "speaker":         getattr(intent, "speaker", ""),
                "semantic":        getattr(intent, "semantic", {}),
                "attributes":      {},
                "signatures":      getattr(intent, "signatures", {}),
                "metadata":        getattr(intent, "metadata", {}),
                "in_response_to":  getattr(intent, "in_response_to", None),
            }
            # Sérialiser les attributs manuellement
            attrs = getattr(intent, "attributes", {})
            for k, v in attrs.items():
                d["attributes"][k] = {
                    "type":  getattr(v, "type", "string"),
                    "value": str(getattr(v, "value", "")),
                }
        return d

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "iso_time":  self.iso_time,
            "source":    self.source,
            "intent":    self.intent_data,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "NarrativeEntry":
        e = object.__new__(cls)
        e.timestamp   = d["timestamp"]
        e.iso_time    = d["iso_time"]
        e.source      = d.get("source", "unknown")
        e.intent_data = d["intent"]
        return e


# ============================================================
# STORE NARRATIF
# ============================================================

class NarrativeStore:
    """
    Mémoire narrative immuable.

    Interface publique :
      push(intent, source)     — entrée depuis l'extérieur (non bloquant)
      archive_today()          — archivage nocturne (appelé par CognitionCore)
      query(...)               — lecture isolée
      start() / stop()         — gestion du worker de persistance
    """

    TODAY_FILENAME = "today.json"

    def __init__(self, narrative_dir: Path, gem_id: str):
        """
        narrative_dir : répertoire racine de la mémoire narrative
        gem_id        : identifiant de l'embodiment courant (depuis Gem)
        """
        self.narrative_dir = Path(narrative_dir)
        self.gem_id        = gem_id

        # Répertoires
        self.livre_dir  = self.narrative_dir / gem_id
        self.courant_dir = self.narrative_dir / "courant"
        self.today_path  = self.courant_dir / self.TODAY_FILENAME

        self.livre_dir.mkdir(parents=True, exist_ok=True)
        self.courant_dir.mkdir(parents=True, exist_ok=True)

        # Buffer RAM du jour
        self._today_buffer: List[NarrativeEntry] = []
        self._buffer_lock = threading.RLock()

        # Queue d'entrée (fire-and-forget)
        self._queue: queue.Queue = queue.Queue()

        # Worker
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None

        # Charger le buffer du jour depuis disque si existant
        self._load_today_from_disk()

        logger.info(
            f"NarrativeStore initialisé — livre: {gem_id}, "
            f"{len(self._today_buffer)} entrées aujourd'hui"
        )

    # ----------------------------------------------------------
    # CYCLE DE VIE
    # ----------------------------------------------------------

    def start(self):
        """Démarre le worker de persistance."""
        self._running = True
        self._worker_thread = threading.Thread(
            target=self._persistence_worker,
            name="narrative-worker",
            daemon=True
        )
        self._worker_thread.start()
        logger.info("NarrativeStore démarré")

    def stop(self):
        """Arrête proprement le worker."""
        self._running = False
        self._queue.put(None)  # sentinelle
        if self._worker_thread:
            self._worker_thread.join(timeout=5)
        # Flush final vers disque
        self._flush_today_to_disk()
        logger.info("NarrativeStore arrêté")

    # ----------------------------------------------------------
    # ENTRÉE (depuis l'extérieur)
    # ----------------------------------------------------------

    def push(self, intent, source: str = "external"):
        """
        Reçoit un intent narratif depuis l'extérieur.
        Non bloquant — fire-and-forget.
        Le worker le persiste de façon asynchrone.
        """
        entry = NarrativeEntry(intent, source)
        self._queue.put(entry)

    # ----------------------------------------------------------
    # ARCHIVAGE NOCTURNE
    # ----------------------------------------------------------

    def archive_today(self):
        """
        Appelé par le cycle nocturne de CognitionCore.
        Archive les entrées du jour dans la page appropriée du livre,
        puis vide le buffer.
        """
        logger.info("📖 Archivage narratif nocturne...")

        with self._buffer_lock:
            if not self._today_buffer:
                logger.info("   Aucune entrée à archiver")
                return

            entries_to_archive = list(self._today_buffer)
            count = len(entries_to_archive)

        # Déterminer la page cible (date d'hier ou du jour selon l'heure)
        target_date = datetime.now().date()
        page_path   = self._page_path(target_date)
        page_path.parent.mkdir(parents=True, exist_ok=True)

        # Charger la page existante si elle existe (append)
        existing = self._load_page(page_path)
        merged   = existing + [e.to_dict() for e in entries_to_archive]

        # Écrire — immuable : on écrit, on ne réécrit jamais une entrée passée
        self._write_page(page_path, merged)

        # Vider le buffer et today.json
        with self._buffer_lock:
            self._today_buffer.clear()

        if self.today_path.exists():
            self.today_path.unlink()

        logger.info(f"   {count} entrées archivées → {page_path}")

    # ----------------------------------------------------------
    # INTERROGATION (lecture isolée)
    # ----------------------------------------------------------

    def query(self,
              annee:  Optional[int]  = None,
              mois:   Optional[int]  = None,
              jour_debut: Optional[int] = None,
              jour_fin:   Optional[int] = None,
              sub_intent: Optional[str] = None,
              speaker:    Optional[str] = None,
              limit:      int = 100,
              embodiment: Optional[str] = None) -> List[Dict]:
        """
        Interroge la mémoire narrative en lecture seule.
        Retourne une liste de dicts (entrées brutes sérialisées).
        N'affecte pas le graphe principal.

        embodiment : gem_id d'un embodiment passé (None = embodiment courant)
        annee      : filtrer sur une année (None = toutes)
        mois       : filtrer sur un mois (None = tous)
        sub_intent : filtrer sur le sub_intent des intents
        speaker    : filtrer sur le speaker
        limit      : nombre max d'entrées retournées
        """
        livre = embodiment or self.gem_id
        livre_dir = self.narrative_dir / livre

        if not livre_dir.exists():
            logger.warning(f"Livre introuvable : {livre}")
            return []

        entries = []

        # Construire la liste des pages à lire
        pages = self._resolve_pages(livre_dir, annee, mois,
                                    jour_debut, jour_fin)

        for page_path in pages:
            page_entries = self._load_page(page_path)
            entries.extend(page_entries)
            if len(entries) >= limit * 3:  # marge pour le filtrage
                break

        # Ajouter le buffer du jour si on cherche dans l'embodiment courant
        if livre == self.gem_id:
            with self._buffer_lock:
                today_entries = [e.to_dict() for e in self._today_buffer]
            entries.extend(today_entries)

        # Filtrage
        if sub_intent:
            entries = [
                e for e in entries
                if e.get("intent", {}).get("semantic", {})
                   .get("sub_intent") == sub_intent
            ]

        if speaker:
            entries = [
                e for e in entries
                if e.get("intent", {}).get("speaker") == speaker
            ]

        # Tri chronologique
        entries.sort(key=lambda e: e.get("timestamp", 0))

        return entries[:limit]

    def list_embodiments(self) -> List[str]:
        """Liste les embodiments archivés disponibles."""
        if not self.narrative_dir.exists():
            return []
        return [
            d.name for d in self.narrative_dir.iterdir()
            if d.is_dir() and d.name != "courant"
        ]

    def stats(self) -> Dict:
        """Statistiques rapides sur la mémoire narrative."""
        total_pages = 0
        total_size  = 0

        if self.livre_dir.exists():
            for p in self.livre_dir.rglob("*.json.gz"):
                total_pages += 1
                total_size  += p.stat().st_size

        with self._buffer_lock:
            today_count = len(self._today_buffer)

        return {
            "embodiment":    self.gem_id,
            "pages_archivees": total_pages,
            "taille_disque_ko": total_size // 1024,
            "entrees_aujourd_hui": today_count,
            "embodiments_archives": self.list_embodiments()
        }

    # ----------------------------------------------------------
    # WORKER DE PERSISTANCE
    # ----------------------------------------------------------

    def _persistence_worker(self):
        """
        Worker daemon qui consomme la queue d'entrée
        et persiste dans le buffer RAM + today.json.
        """
        flush_counter = 0

        while self._running:
            try:
                entry = self._queue.get(timeout=1.0)

                if entry is None:  # sentinelle d'arrêt
                    break

                with self._buffer_lock:
                    self._today_buffer.append(entry)

                flush_counter += 1

                # Flush vers today.json toutes les 10 entrées
                if flush_counter >= 10:
                    self._flush_today_to_disk()
                    flush_counter = 0

            except queue.Empty:
                # Flush périodique même sans nouvelles entrées
                if flush_counter > 0:
                    self._flush_today_to_disk()
                    flush_counter = 0

    # ----------------------------------------------------------
    # PERSISTANCE today.json
    # ----------------------------------------------------------

    def _flush_today_to_disk(self):
        """Écrit le buffer du jour dans today.json (non compressé, lisible)."""
        with self._buffer_lock:
            data = [e.to_dict() for e in self._today_buffer]

        try:
            with open(self.today_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Erreur flush today : {e}")

    def _load_today_from_disk(self):
        """Charge today.json au démarrage (reprise après crash)."""
        if not self.today_path.exists():
            return
        try:
            with open(self.today_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            with self._buffer_lock:
                self._today_buffer = [
                    NarrativeEntry.from_dict(d) for d in data
                ]
            logger.info(
                f"Buffer narratif restauré : {len(self._today_buffer)} entrées"
            )
        except Exception as e:
            logger.warning(f"Impossible de restaurer today.json : {e}")

    # ----------------------------------------------------------
    # STRUCTURE LIVRE/CHAPITRE/SECTION/PAGE
    # ----------------------------------------------------------

    def _page_path(self, d: date) -> Path:
        """
        Retourne le chemin de la page pour une date donnée.
        Page 1 : jours 1-15, Page 2 : jours 16-fin.
        """
        page_num = 1 if d.day <= 15 else 2
        return (
            self.livre_dir
            / str(d.year)           # chapitre
            / f"{d.month:02d}"      # section
            / f"page_{page_num}.json.gz"
        )

    def _resolve_pages(self, livre_dir: Path,
                       annee: Optional[int],
                       mois:  Optional[int],
                       jour_debut: Optional[int],
                       jour_fin:   Optional[int]) -> List[Path]:
        """
        Résout la liste des fichiers de pages à lire
        selon les critères de filtrage temporels.
        """
        pages = []

        # Parcourir les chapitres (années)
        annees = sorted(livre_dir.iterdir()) if livre_dir.exists() else []
        for annee_dir in annees:
            if not annee_dir.is_dir():
                continue
            if annee and annee_dir.name != str(annee):
                continue

            # Parcourir les sections (mois)
            for mois_dir in sorted(annee_dir.iterdir()):
                if not mois_dir.is_dir():
                    continue
                if mois and mois_dir.name != f"{mois:02d}":
                    continue

                # Parcourir les pages
                for page_file in sorted(mois_dir.glob("page_*.json.gz")):
                    # Filtrage par jour si précisé
                    if jour_debut or jour_fin:
                        page_num = int(page_file.stem.split("_")[1])
                        page_start = 1  if page_num == 1 else 16
                        page_end   = 15 if page_num == 1 else 31
                        jd = jour_debut or 1
                        jf = jour_fin   or 31
                        # Inclure si les plages se chevauchent
                        if jf < page_start or jd > page_end:
                            continue
                    pages.append(page_file)

        return pages

    # ----------------------------------------------------------
    # LECTURE / ÉCRITURE PAGES
    # ----------------------------------------------------------

    def _load_page(self, page_path: Path) -> List[Dict]:
        """Charge une page depuis disque. Retourne [] si absente."""
        if not page_path.exists():
            return []
        try:
            with gzip.open(page_path, "rt", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Erreur lecture page {page_path} : {e}")
            return []

    def _write_page(self, page_path: Path, entries: List[Dict]):
        """
        Écrit une page sur disque (compressée).
        Immuabilité : on n'écrase que si on ajoute des entrées
        (archivage nocturne). Les pages passées ne sont jamais réécrites.
        """
        try:
            with gzip.open(page_path, "wt", encoding="utf-8") as f:
                json.dump(entries, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Erreur écriture page {page_path} : {e}")
